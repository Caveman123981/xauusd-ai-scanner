const assert = require('node:assert/strict');
require('../src/data-integrity.js');
require('../src/algospecial-provider.js');
require('../src/indicators.js');
require('../src/market-analyst.js');
require('../src/signal-analyst.js');
require('../src/risk-analyst.js');
require('../src/quality-reviewer.js');
require('../src/orchestrator.js');
require('../src/backtester.js');
require('../src/audit-ledger.js');
const X = globalThis.XAUUSD;
let passed = 0;
async function test(name, fn) { await fn(); passed++; process.stdout.write(`PASS ${name}\n`); }
async function main() {
function makeCandles(n, start, step, closeFn) {
  return Array.from({ length: n }, (_, i) => { const close = closeFn(i); return { time: new Date(start + i * step).toISOString(), timestamp: start + i * step, open: close - 0.2, high: close + 0.5, low: close - 0.5, close }; });
}
await test('EMA returns null warm-up and expected seeded average', () => {
  const e = X.Indicators.ema([1,2,3,4,5], 3);
  assert.equal(e[0], null); assert.equal(e[2], 2); assert.ok(Math.abs(e[3] - 3) < 1e-12);
});
await test('RSI flat series returns neutral 50 after warm-up', () => {
  const r = X.Indicators.rsi(Array(20).fill(10), 14);
  assert.equal(r[13], null); assert.equal(r[14], 50); assert.equal(r[19], 50);
});
await test('RSI monotonic gain series returns 100', () => {
  const r = X.Indicators.rsi(Array.from({length:20}, (_,i)=>i+1), 14);
  assert.equal(r[19], 100);
});
await test('ATR Wilder smoothing returns positive values', () => {
  const c = makeCandles(20, Date.UTC(2026,0,1), 900000, i => 100 + i);
  const a = X.Indicators.atr(c, 14);
  assert.equal(a[13], null); assert.ok(a[14] > 0); assert.ok(a[19] > 0);
});
await test('CSV parser accepts MetaTrader timestamps and validates OHLC', () => {
  const csv = 'time,open,high,low,close\n2026.11.10 10:00,100,102,99,101\n2026.11.10 11:00,101,103,100,102';
  const p = X.DataIntegrity.parseCSV(csv, 'H1');
  assert.equal(p.candles.length, 2); assert.equal(p.validation.valid, true);
});
await test('CSV parser rejects timezone-naive ISO timestamps', () => {
  const csv = 'time,open,high,low,close\n2026-11-10T10:00:00,100,102,99,101';
  assert.throws(() => X.DataIntegrity.parseCSV(csv, 'H1'), /Timezone-naive ISO\/local timestamps/);
});
await test('CSV parser accepts explicit ISO offsets as absolute timestamps', () => {
  const csv = 'time,open,high,low,close\n2026-11-10T12:00:00+02:00,100,102,99,101\n2026-11-10T13:00:00+02:00,101,103,100,102';
  const p = X.DataIntegrity.parseCSV(csv, 'H1');
  assert.equal(p.timestampBasis, 'absolute');
  assert.equal(p.candles[0].timestamp, Date.UTC(2026, 10, 10, 10));
});
await test('CSV parser rejects mixing broker wall-clock and absolute timestamp bases', () => {
  const csv = 'time,open,high,low,close\n2026.11.10 10:00,100,102,99,101\n2026-11-10T11:00:00Z,101,103,100,102';
  assert.throws(() => X.DataIntegrity.parseCSV(csv, 'H1'), /mixes broker-server wall-clock timestamps/);
});
await test('CSV parser rejects impossible MetaTrader calendar dates', () => {
  const csv = 'time,open,high,low,close\n2026.13.40 10:00,100,102,99,101';
  assert.throws(() => X.DataIntegrity.parseCSV(csv, 'H1'), /invalid or unsupported timestamp/);
});
await test('CSV parser rejects duplicate timestamps', () => {
  const csv = 'time,open,high,low,close\n2026-11-10T10:00:00Z,100,102,99,101\n2026-11-10T10:00:00Z,101,103,100,102';
  assert.throws(() => X.DataIntegrity.parseCSV(csv, 'H1'), /Duplicate candle timestamp/);
});
await test('CSV parser accepts provider Timestamp and preserves spread/tick volume', () => {
  const csv = 'Timestamp,Open,High,Low,Close,TickVolume,Spread\n2026.10.30 10:00:00,100,102,99,101,120,25\n2026.10.30 11:00:00,101,103,100,102,140,27';
  const p = X.DataIntegrity.parseCSV(csv, 'H1');
  assert.equal(p.candles[0].tickVolume, 120);
  assert.equal(p.candles[0].spreadPoints, 25);
});
await test('AlgoSpecial adapter fetches and normalizes historical CSV without an API key', async () => {
  let requested = '';
  const mockFetch = async (url) => { requested = url; return {ok:true,status:200,text:async()=> 'Timestamp,Open,High,Low,Close\n2026.10.30 10:00:00,100,102,99,101\n2026.10.30 11:00:00,101,103,100,102'}; };
  const p = await X.AlgoSpecialProvider.fetchCandles({timeframe:'H1',from:'2026-10-30',to:'2026-10-30',fetchImpl:mockFetch});
  assert.equal(p.candles.length,2); assert.equal(p.source,'AlgoSpecial free historical preview');
  assert.match(requested,/symbol=XAUUSD/); assert.match(requested,/tf=H1/); assert.match(requested,/format=csv/);
});
await test('AlgoSpecial adapter rejects date ranges beyond the free preview cap', async () => {
  await assert.rejects(() => X.AlgoSpecialProvider.fetchCandles({timeframe:'M15',from:'2026-09-01',to:'2026-10-02',fetchImpl:async()=>{throw Error('should not fetch');}}), /31 calendar days/);
});
await test('timeframe validator accepts legitimate session gaps but rejects irregular sub-interval spacing', () => {
  const h1 = makeCandles(3, Date.UTC(2026,0,1), 3600000, i => 100+i);
  h1[2].timestamp += 30*60*1000;
  const validation = X.DataIntegrity.validateCandles(h1, 'H1');
  assert.equal(validation.valid, false);
  assert.match(validation.errors.join(' '), /not an integer multiple/);
  const withSessionGap = makeCandles(3, Date.UTC(2026,0,1), 3600000, i => 100+i);
  withSessionGap[2].timestamp += 24*3600000;
  const gapValidation = X.DataIntegrity.validateCandles(withSessionGap, 'H1');
  assert.equal(gapValidation.valid, true);
  assert.equal(gapValidation.gaps, 1);
});
await test('dataset validation rejects H1 opens off the M15 interval grid', () => {
  const start = Date.UTC(2026,0,1);
  const h1 = {candles:makeCandles(210,start,3600000,i=>100+i),validation:{warnings:[]},timestampBasis:'absolute'};
  const m15 = {candles:makeCandles(900,start,900000,i=>100+i),validation:{warnings:[]},timestampBasis:'absolute'};
  for (const candle of h1.candles) candle.timestamp += 5*60*1000;
  const result = X.DataIntegrity.validateDataset(h1,m15);
  assert.equal(result.valid,false);
  assert.match(result.errors.join(' '),/does not align to the M15 timeline/);
});
await test('timeframe alignment accepts a non-hour-offset broker phase without assuming UTC boundaries', () => {
  const start = Date.UTC(2026,0,1,0,15);
  const h1 = makeCandles(210,start-15*60*1000,3600000,i=>100+i);
  const m15 = makeCandles(40,start,900000,i=>100+i);
  assert.deepEqual(X.DataIntegrity.validateTimeframeAlignment(h1,m15),[]);
});
await test('dataset validation rejects different H1 and M15 timestamp bases', () => {
  const h1 = {candles:makeCandles(210,Date.UTC(2026,0,1),3600000,i=>100+i),validation:{warnings:[]},timestampBasis:'broker_server_wall_clock'};
  const m15 = {candles:makeCandles(30,Date.UTC(2026,0,1),900000,i=>100+i),validation:{warnings:[]},timestampBasis:'absolute'};
  const result = X.DataIntegrity.validateDataset(h1,m15);
  assert.equal(result.valid,false);
  assert.match(result.errors.join(' '),/timestamp bases differ/);
});
await test('CSV parser rejects malformed OHLC', () => {
  const csv = 'time,open,high,low,close\n2026-11-10T10:00:00Z,100,99,98,101';
  assert.throws(() => X.DataIntegrity.parseCSV(csv, 'H1'), /inconsistent OHLC/);
});
await test('position sizing floors to broker lot step and stays within risk budget', () => {
  const r = X.RiskAnalyst.calculatePositionSize({balance:1000,riskPercent:0.5,stopDistance:10,usdPerOneDollarMovePerLot:10,minLot:0.01,lotStep:0.01,maxLot:10});
  assert.equal(r.valid, true); assert.equal(r.lots, 0.05); assert.ok(r.estimatedRisk <= r.riskCash);
});
await test('position sizing rejects risk above one percent', () => {
  const r = X.RiskAnalyst.calculatePositionSize({balance:1000,riskPercent:2,stopDistance:10,usdPerOneDollarMovePerLot:100});
  assert.equal(r.valid, false);
});
await test('orchestrator fails closed on insufficient history', () => {
  const h1 = {candles:makeCandles(199,Date.UTC(2026,0,1),3600000,i=>100+i),validation:{warnings:[]}};
  const m15 = {candles:makeCandles(40,Date.UTC(2026,0,1),900000,i=>100+i),validation:{warnings:[]}};
  const r = X.Orchestrator.scan(h1,m15);
  assert.equal(r.decision,'WAIT'); assert.equal(r.stage,'DATA_REJECTED');
});
await test('orchestrator excludes an incomplete latest H1 candle', () => {
  const start = Date.UTC(2026, 0, 1);
  const h1 = makeCandles(210, start, 3600000, i => 100 + i * 0.2);
  const m15 = makeCandles(50, start + 209 * 3600000 - 49 * 900000, 900000, i => 140 + i * 0.01);
  const r = X.Orchestrator.scan({candles:h1,validation:{valid:true,warnings:[]}},{candles:m15,validation:{valid:true,warnings:[]}});
  assert.equal(r.decision, 'WAIT'); assert.equal(r.stage, 'DATA_REJECTED');
  assert.match(r.reasons.join(' '), /completed H1 candles/);
});
await test('orchestrator excludes the unconfirmed final M15 candle and signals on the prior completed candle', () => {
  const start = Date.UTC(2026, 0, 1);
  const h1 = makeCandles(220, start, 3600000, i => 100 + i * 0.2);
  const m15 = makeCandles(40, start + 219 * 3600000 - 39 * 900000, 900000, i => 140 + i * 0.01);
  const r = X.Orchestrator.scan({candles:h1,validation:{warnings:[]}},{candles:m15,validation:{warnings:[]}});
  assert.equal(r.stage, 'COMPLETE');
  assert.equal(r.completedM15Count, 39);
  assert.equal(r.signal.candleTime, m15[38].time);
  assert.equal(r.signalCandleIndex, 38);
});
await test('orchestrator refuses M15 data without 30 demonstrably completed candles', () => {
  const start = Date.UTC(2026, 0, 1);
  const h1 = makeCandles(220, start, 3600000, i => 100 + i * 0.2);
  const m15 = makeCandles(30, start + 219 * 3600000 - 29 * 900000, 900000, i => 140 + i * 0.01);
  const r = X.Orchestrator.scan({candles:h1,validation:{warnings:[]}},{candles:m15,validation:{warnings:[]}});
  assert.equal(r.stage, 'DATA_REJECTED');
  assert.match(r.reasons.join(' '), /demonstrably completed M15 candles/);
});
await test('completed M15 selection handles gaps but rejects too-short follow-on intervals', () => {
  const start = Date.UTC(2026, 0, 1);
  const candles = makeCandles(4, start, 900000, i => 100 + i);
  candles[3].timestamp = candles[2].timestamp + 5 * 60 * 1000;
  assert.equal(X.Orchestrator.latestCompletedCandleIndex(candles, 900000), 1);
  candles[3].timestamp = candles[2].timestamp + 30 * 60 * 1000;
  assert.equal(X.Orchestrator.latestCompletedCandleIndex(candles, 900000), 2);
});
await test('orchestrator produces a reviewed BUY candidate from aligned synthetic data', () => {
  const start = Date.UTC(2026, 10, 10, 8, 0);
  const h1Candles = makeCandles(240, start, 3600000, i => 180 + i * 0.3);
  const h1End = start + 239 * 3600000;
  const m15Candles = Array.from({length:80}, (_,i) => {
    let close = 200 + i * 0.05 + Math.sin(i * 0.9);
    if (i === 78) close += 0.8;
    const timestamp = h1End - (79 - i) * 900000;
    return {time:new Date(timestamp).toISOString(),timestamp,open:close-0.15,high:close+0.5,low:close-0.5,close};
  });
  const result = X.Orchestrator.scan({candles:h1Candles,validation:{warnings:[]}},{candles:m15Candles,validation:{warnings:[]}});
  assert.equal(result.market.trend, 'BULLISH');
  assert.equal(result.signal.candidate, 'BUY');
  assert.equal(result.signal.candleTime, m15Candles[78].time);
  assert.equal(result.decision, 'BUY');
  assert.equal(result.review.verdict, 'PASS');
  assert.ok(result.risk.stopLoss < result.signal.close);
  assert.ok(result.risk.takeProfit > result.signal.close);
});
await test('quality reviewer rejects BUY against bearish market', () => {
  const d={valid:true},m={trend:'BEARISH'},s={candidate:'BUY',rsi14:60,atr14:1},risk={valid:true,stopLoss:99,takeProfit:102};
  const r=X.QualityReviewer.review(d,m,s,risk);
  assert.equal(r.approved,false); assert.match(r.issues.join(' '),/conflicts/);
});

await test('backtester enters on next bar open and records a target exit', () => {
  const candles = [
    {open:100,high:100.5,low:99.8,close:100.2},
    {open:100.1,high:102.2,low:99.9,close:102}
  ];
  const t = X.Backtester.simulateTrade({side:'BUY',entryPrice:100.1,stopDistance:1,rewardRisk:2,candles,startIndex:0,maxHoldingBars:10});
  assert.equal(t.status,'CLOSED'); assert.equal(t.exitReason,'TARGET'); assert.equal(t.exitPrice,102.1); assert.equal(t.netR,2);
});
await test('backtester uses conservative stop-first rule when stop and target touch same bar', () => {
  const candles = [{open:100,high:103,low:98,close:101}];
  const t = X.Backtester.simulateTrade({side:'BUY',entryPrice:100,stopDistance:1,rewardRisk:2,candles,startIndex:0});
  assert.equal(t.exitReason,'STOP_AND_TARGET_SAME_BAR_STOP_FIRST'); assert.equal(t.netR,-1);
});
await test('backtester charges explicit round-trip costs in R', () => {
  const candles = [{open:100,high:102.1,low:99.9,close:102}];
  const t = X.Backtester.simulateTrade({side:'BUY',entryPrice:100,stopDistance:1,rewardRisk:2,candles,startIndex:0,roundTripCostPrice:0.2});
  assert.equal(t.netR,1.8);
});
await test('backtester adds explicit spread, commission and slippage round-trip costs', () => {
  const candles = [{open:100,high:102.1,low:99.9,close:102}];
  const t = X.Backtester.simulateTrade({side:'BUY',entryPrice:100,stopDistance:1,rewardRisk:2,candles,startIndex:0,spreadCostPrice:0.1,commissionCostPrice:0.05,slippageCostPrice:0.05});
  assert.equal(t.grossR,2); assert.equal(t.roundTripCostPrice,0.2); assert.equal(t.netR,1.8);
  assert.deepEqual(t.costBreakdown,{legacyAggregate:0,spread:0.1,commission:0.05,slippage:0.05});
});
await test('backtester rejects negative or non-finite cost components', () => {
  const candles = [{open:100,high:102.1,low:99.9,close:102}];
  const t = X.Backtester.simulateTrade({side:'BUY',entryPrice:100,stopDistance:1,candles,startIndex:0,commissionCostPrice:-0.1});
  assert.equal(t.status,'INVALID'); assert.match(t.error,/costs/);
});
await test('backtester leaves trades open when data ends before a stop, target or time exit', () => {
  const candles = [{open:100,high:100.2,low:99.8,close:100.1}];
  const t = X.Backtester.simulateTrade({side:'BUY',entryPrice:100,stopDistance:1,rewardRisk:2,candles,startIndex:0,maxHoldingBars:10});
  assert.equal(t.status,'OPEN_AT_DATA_END');
});
await test('backtester skips a candidate when the next observed M15 candle is separated by a gap', () => {
  const start = Date.UTC(2026,0,1);
  const h1Candles = makeCandles(300,start,3600000,i=>180+i*.08);
  const m15Candles = makeCandles(100,start+299*3600000-99*900000,900000,i=>204+i*.015);
  const signalIndex = 40;
  for (let i = signalIndex+1; i < m15Candles.length; i++) m15Candles[i].timestamp += 15*60*1000;
  const originalSignal = X.SignalAnalyst.analyzeM15;
  const originalRisk = X.RiskAnalyst.assess;
  const originalReview = X.QualityReviewer.review;
  X.SignalAnalyst.analyzeM15 = candles => candles.at(-1).timestamp === m15Candles[signalIndex].timestamp ? {candidate:'BUY'} : {candidate:'WAIT'};
  X.RiskAnalyst.assess = () => ({valid:true,stopDistance:1});
  X.QualityReviewer.review = () => ({approved:true});
  try {
    const r = X.Backtester.run({h1:{candles:h1Candles,validation:{valid:true}},m15:{candles:m15Candles,validation:{valid:true}},settings:{signalStartTime:m15Candles[signalIndex].timestamp}});
    assert.equal(r.valid,true);
    assert.equal(r.signals,1);
    assert.equal(r.skippedGapEntries,1);
    assert.equal(r.trades.length,0);
  } finally {
    X.SignalAnalyst.analyzeM15 = originalSignal;
    X.RiskAnalyst.assess = originalRisk;
    X.QualityReviewer.review = originalReview;
  }
});
await test('backtester independently rejects irregular H1 candle spacing', () => {
  const start = Date.UTC(2026,0,1);
  const h1 = makeCandles(210,start,3600000,i=>100+i);
  const m15 = makeCandles(40,start,900000,i=>100+i);
  h1[150].timestamp += 5*60*1000;
  const r = X.Backtester.run({h1:{candles:h1,validation:{valid:true}},m15:{candles:m15,validation:{valid:true}}});
  assert.equal(r.valid,false);
  assert.match(r.errors.join(' '),/irregular spacing/);
});
await test('backtester independently rejects irregular M15 candle spacing', () => {
  const start = Date.UTC(2026,0,1);
  const h1 = makeCandles(210,start,3600000,i=>100+i);
  const m15 = makeCandles(900,start,900000,i=>100+i);
  m15[500].timestamp += 5*60*1000;
  const r = X.Backtester.run({h1:{candles:h1,validation:{valid:true}},m15:{candles:m15,validation:{valid:true}}});
  assert.equal(r.valid,false);
  assert.match(r.errors.join(' '),/M15 candle 501 has irregular spacing/);
});
await test('backtester independently rejects H1 timestamps off the M15 grid', () => {
  const start = Date.UTC(2026,0,1);
  const h1 = makeCandles(210,start,3600000,i=>100+i);
  const m15 = makeCandles(900,start,900000,i=>100+i);
  for (const candle of h1) candle.timestamp += 5*60*1000;
  const r = X.Backtester.run({h1:{candles:h1,validation:{valid:true}},m15:{candles:m15,validation:{valid:true}}});
  assert.equal(r.valid,false);
  assert.match(r.errors.join(' '),/does not align to the M15 timeline/);
});
await test('backtester independently rejects duplicate or out-of-order timestamps', () => {
  const h1 = makeCandles(220,Date.UTC(2026,0,1),3600000,i=>100+i*.1);
  const m15 = makeCandles(100,Date.UTC(2026,0,1),900000,i=>100+i*.01);
  m15[50].timestamp = m15[49].timestamp;
  const r = X.Backtester.run({h1:{candles:h1,validation:{valid:true}},m15:{candles:m15,validation:{valid:true}}});
  assert.equal(r.valid,false); assert.match(r.errors.join(' '), /duplicate or out-of-order timestamp/);
});
await test('backtester independently rejects malformed OHLC despite a forged validation flag', () => {
  const h1 = makeCandles(220,Date.UTC(2026,0,1),3600000,i=>100+i*.1);
  const m15 = makeCandles(100,Date.UTC(2026,0,1),900000,i=>100+i*.01);
  m15[50].high = m15[50].low - 1;
  const r = X.Backtester.run({h1:{candles:h1,validation:{valid:true}},m15:{candles:m15,validation:{valid:true}}});
  assert.equal(r.valid,false); assert.match(r.errors.join(' '), /inconsistent OHLC/);
});
await test('single-trade simulator rejects invalid execution OHLC', () => {
  const t = X.Backtester.simulateTrade({side:'BUY',entryPrice:100,stopDistance:1,candles:[{open:100,high:99,low:98,close:100}],startIndex:0});
  assert.equal(t.status,'INVALID'); assert.match(t.error, /inconsistent OHLC/);
});
await test('backtester rejects datasets without valid validation flags', () => {
  const candles = makeCandles(220,Date.UTC(2026,0,1),3600000,i=>100+i*.1);
  const m15 = makeCandles(1000,Date.UTC(2026,0,1),900000,i=>100+i*.01);
  const r = X.Backtester.run({h1:{candles,validation:{valid:false}},m15:{candles:m15,validation:{valid:true}}});
  assert.equal(r.valid,false); assert.match(r.errors.join(' '),/pass candle validation/);
});
await test('backtester runs a validated walk-forward dataset without throwing', () => {
  const start = Date.UTC(2026, 0, 1);
  const h1Candles = makeCandles(300, start, 3600000, i => 180 + i * 0.08);
  const m15Start = start + 299 * 3600000;
  const m15Candles = makeCandles(500, m15Start, 900000, i => 204 + i * 0.015 + Math.sin(i / 5) * 0.1);
  const result = X.Backtester.run({
    h1: {candles:h1Candles,validation:{valid:true,warnings:[]}},
    m15: {candles:m15Candles,validation:{valid:true,warnings:[]}},
    settings: {maxHoldingBars:32,roundTripCostPrice:0.1}
  });
  assert.equal(result.valid, true); assert.ok(result.summary.closedTrades >= 0);
  assert.match(result.method, /completed-H1-only/);
});
await test('elapsed exposure bounds distinguish intrabar exit uncertainty from bar-open gap exits', () => {
  const start = Date.UTC(2026, 0, 1);
  const intrabar = X.Backtester.simulateTrade({side:'BUY',entryPrice:100,stopDistance:1,rewardRisk:2,candles:[
    {timestamp:start,open:100,high:100.5,low:99.5,close:100.1},
    {timestamp:start+900000,open:100.1,high:102.5,low:100,close:102.2}
  ],startIndex:0,maxHoldingBars:2});
  assert.equal(intrabar.status,'CLOSED'); assert.equal(intrabar.exitTimingPrecision,'INTRABAR_UNKNOWN');
  assert.equal(intrabar.elapsedExposureLowerBoundMinutes,15); assert.equal(intrabar.elapsedExposureUpperBoundMinutes,30);
  const gap = X.Backtester.simulateTrade({side:'BUY',entryPrice:100,stopDistance:1,rewardRisk:2,candles:[
    {timestamp:start,open:100,high:100.5,low:99.5,close:100.1},
    {timestamp:start+900000,open:103,high:103.5,low:102.5,close:103.2}
  ],startIndex:0,maxHoldingBars:2});
  assert.equal(gap.exitTimingPrecision,'BAR_OPEN'); assert.equal(gap.elapsedExposureLowerBoundMinutes,15); assert.equal(gap.elapsedExposureUpperBoundMinutes,15);
});
await test('elapsed exposure reports modelled time exit and unresolved last-bar bounds', () => {
  const start = Date.UTC(2026, 0, 1);
  const candles = [0,1].map(i=>({timestamp:start+i*900000,open:100,high:100.5,low:99.5,close:100.1}));
  const timed = X.Backtester.simulateTrade({side:'BUY',entryPrice:100,stopDistance:1,candles,startIndex:0,maxHoldingBars:2});
  assert.equal(timed.exitTimingPrecision,'BAR_CLOSE_MODELLED'); assert.equal(timed.elapsedExposureLowerBoundMinutes,30); assert.equal(timed.elapsedExposureUpperBoundMinutes,30);
  const unresolved = X.Backtester.simulateTrade({side:'BUY',entryPrice:100,stopDistance:1,candles,startIndex:0,maxHoldingBars:3});
  assert.equal(unresolved.status,'OPEN_AT_DATA_END'); assert.equal(unresolved.exitTimingPrecision,'UNRESOLVED_WITHIN_LAST_OBSERVED_BAR');
  assert.equal(unresolved.elapsedExposureLowerBoundMinutes,15); assert.equal(unresolved.elapsedExposureUpperBoundMinutes,30);
});
await test('M15 coverage separates observed candles from missing timestamp-grid slots', () => {
  const start = Date.UTC(2026, 0, 1);
  const candles = [0, 1, 3, 4].map(i => ({timestamp:start + i * 900000}));
  const coverage = X.Backtester.measureM15Coverage(candles);
  assert.equal(coverage.observedCandles, 4);
  assert.equal(coverage.gapCount, 1);
  assert.equal(coverage.missingIntervalSlots, 1);
  assert.equal(coverage.maxGapMinutes, 30);
  assert.equal(coverage.elapsedWindowMinutes, 75);
  assert.equal(coverage.gridSlots, 5);
  assert.equal(coverage.timestampGridCoveragePercent, 80);
  assert.match(coverage.interpretation, /not market-open coverage/);
});
await test('M15 coverage can isolate a chronological holdout window', () => {
  const start = Date.UTC(2026, 0, 1);
  const candles = [0, 1, 3, 4, 5].map(i => ({timestamp:start + i * 900000}));
  const coverage = X.Backtester.measureM15Coverage(candles, 2, 4);
  assert.equal(coverage.observedCandles, 3);
  assert.equal(coverage.gapCount, 0);
  assert.equal(coverage.missingIntervalSlots, 0);
  assert.equal(coverage.gridSlots, 3);
  assert.equal(coverage.timestampGridCoveragePercent, 100);
});
await test('out-of-sample holdout rejects invalid split fractions', () => {
  const r = X.Backtester.runOutOfSample({h1:{candles:[],validation:{valid:true}},m15:{candles:[],validation:{valid:true}},trainFraction:0.95});
  assert.equal(r.valid, false); assert.match(r.errors.join(' '), /between 0.50 and 0.90/);
});
await test('out-of-sample holdout gates all signal evaluation to the final chronological segment', () => {
  const start = Date.UTC(2026, 0, 1);
  const h1Candles = makeCandles(300, start, 3600000, i => 180 + i * 0.08);
  const m15Candles = makeCandles(500, start + 299 * 3600000, 900000, i => 204 + i * 0.015 + Math.sin(i / 5) * 0.1);
  const original = X.SignalAnalyst.analyzeM15;
  let calls = 0;
  X.SignalAnalyst.analyzeM15 = () => { calls++; return {candidate:'WAIT'}; };
  try {
    const r = X.Backtester.runOutOfSample({h1:{candles:h1Candles,validation:{valid:true,warnings:[]}},m15:{candles:m15Candles,validation:{valid:true,warnings:[]}},trainFraction:0.7});
    assert.equal(r.valid, true);
    assert.equal(r.splitIndex, 350);
    assert.equal(calls, 149);
    assert.equal(r.result.signals, 0);
    assert.equal(r.result.evaluationStartTime, m15Candles[350].timestamp);
    assert.equal(r.testStartIndex, 350); assert.equal(r.testEndIndex, 499);
    assert.equal(r.testEndTime, m15Candles[499].time);
    assert.equal(r.testCoverage.observedCandles, 150);
    assert.equal(r.testCoverage.gapCount, 0);
    assert.equal(r.testCoverage.timestampGridCoveragePercent, 100);
    assert.match(r.boundaryPolicy, /no candles beyond the test window/);
    assert.match(r.method, /no parameter fitting/);
  } finally { X.SignalAnalyst.analyzeM15 = original; }
});
await test('unresolved end-of-data trade blocks later overlapping signal entries', () => {
  const start = Date.UTC(2026, 0, 1);
  const h1Candles = makeCandles(220, start, 3600000, () => 200);
  const m15Candles = makeCandles(100, start + 219 * 3600000, 900000, () => 200);
  const originalMarket = X.MarketAnalyst.analyzeH1;
  const originalSignal = X.SignalAnalyst.analyzeM15;
  X.MarketAnalyst.analyzeH1 = () => ({trend:'BULLISH'});
  let signalCalls = 0;
  X.SignalAnalyst.analyzeM15 = () => { signalCalls++; return {candidate:'BUY',close:200,atr14:1,rsi14:55}; };
  try {
    const r = X.Backtester.run({
      h1:{candles:h1Candles,validation:{valid:true}},
      m15:{candles:m15Candles,validation:{valid:true}},
      settings:{maxHoldingBars:96}
    });
    assert.equal(r.valid,true);
    assert.equal(r.signals,1);
    assert.equal(r.unresolvedSignals,1);
    assert.equal(signalCalls,1);
    assert.equal(r.trades.length,0);
    assert.equal(r.unresolvedTrades.length,1);
    assert.equal(r.unresolvedTrades[0].status,'UNRESOLVED');
    assert.equal(r.unresolvedTrades[0].side,'BUY');
    assert.equal(r.unresolvedTrades[0].entryTime,m15Candles[r.unresolvedTrades[0].entryIndex].time);
    assert.equal(r.unresolvedTrades[0].lastObservedTime,m15Candles[99].time);
    assert.equal(r.unresolvedTrades[0].lastObservedClose,m15Candles[99].close);
    assert.equal(r.unresolvedTrades.length,1);
    assert.equal(r.unresolvedTrades[0].status,'UNRESOLVED');
    assert.equal(r.unresolvedTrades[0].side,'BUY');
    assert.equal(r.unresolvedTrades[0].entryTime,m15Candles[r.unresolvedTrades[0].entryIndex].time);
    assert.equal(r.unresolvedTrades[0].lastObservedTime,m15Candles[99].time);
    assert.equal(r.unresolvedTrades[0].lastObservedClose,m15Candles[99].close);
  } finally {
    X.MarketAnalyst.analyzeH1 = originalMarket;
    X.SignalAnalyst.analyzeM15 = originalSignal;
  }
});
await test('audit ledger exports stable identifiers, costs and source date ranges', () => {
  const h1 = {candles:makeCandles(2,Date.UTC(2026,0,1),3600000,i=>100+i),timestampBasis:'broker_server_wall_clock'};
  const m15 = {candles:makeCandles(3,Date.UTC(2026,0,1),900000,i=>100+i),timestampBasis:'broker_server_wall_clock'};
  const result = {valid:true,method:'bar-close; next-open',parameters:{atrMultiplier:1.5,rewardRisk:2,maxHoldingBars:96},trades:[{status:'CLOSED',side:'BUY',entryIndex:1,exitIndex:2,entryPrice:101,stopLoss:100, takeProfit:103,exitPrice:103,exitReason:'TARGET',barsHeld:2,elapsedExposureLowerBoundMinutes:15,elapsedExposureUpperBoundMinutes:30,exitTimingPrecision:'INTRABAR_UNKNOWN',grossR:2,netR:1.8,costR:0.2,roundTripCostPrice:0.2,costBreakdown:{legacyAggregate:0,spread:0.1,commission:0.05,slippage:0.05}}]};
  const csv = X.AuditLedger.createCSV({result,h1,m15});
  assert.match(csv,/XAU-1767226500000-0001/); assert.match(csv,/spread_cost_price,commission_cost_price,slippage_cost_price/);
  assert.match(csv,/elapsed_exposure_lower_bound_minutes,elapsed_exposure_upper_bound_minutes,exit_timing_precision/); assert.match(csv,/15,30,INTRABAR_UNKNOWN/); assert.match(csv,/2026-01-01T00:00:00.000Z/); assert.match(csv,/broker_server_wall_clock/); assert.match(csv,/bar-close; next-open/);
  assert.equal(csv,X.AuditLedger.createCSV({result,h1,m15}));
});
await test('audit ledger records unresolved positions separately from closed trades', () => {
  const h1={candles:makeCandles(2,Date.UTC(2026,0,1),3600000,i=>100+i)};
  const m15={candles:makeCandles(4,Date.UTC(2026,0,1),900000,i=>100+i)};
  const result={valid:true,method:'test method',parameters:{atrMultiplier:1.5,rewardRisk:2,maxHoldingBars:96},trades:[],unresolvedTrades:[{status:'UNRESOLVED',side:'SELL',entryIndex:1,lastObservedIndex:3,entryPrice:101,stopLoss:102,takeProfit:99,barsHeld:3,lastObservedClose:100.5,elapsedExposureLowerBoundMinutes:30,elapsedExposureUpperBoundMinutes:45,exitTimingPrecision:'UNRESOLVED_WITHIN_LAST_OBSERVED_BAR'}]};
  const csv=X.AuditLedger.createCSV({result,h1,m15});
  assert.match(csv,/UNRESOLVED_POSITION/); assert.match(csv,/unresolved_position_count/); assert.match(csv,/RUN_METADATA/);
  const row=csv.split('\r\n').find(line=>line.startsWith('UNRESOLVED_POSITION,'));
  assert.ok(row); assert.match(row,/SELL/); assert.match(row,/100\.5/); assert.match(row,/30,45,UNRESOLVED_WITHIN_LAST_OBSERVED_BAR/);
  assert.doesNotMatch(row,/TIME_EXIT|STOP|TARGET/);
  assert.equal(csv.split('\r\n').filter(line=>line.startsWith('TRADE,')).length,0);
});
await test('audit ledger safely escapes commas, quotes and newlines', () => {
  const h1={candles:[]},m15={candles:[]};
  const result={valid:true,method:'method, with "quotes"\nand newline',parameters:{roundTripCostPrice:0,spreadCostPrice:0.12,commissionCostPrice:0.08,slippageCostPrice:0.03,totalRoundTripCostPrice:0.23},trades:[]};
  const csv=X.AuditLedger.createCSV({result,h1,m15});
  assert.match(csv,/RUN_METADATA/); assert.match(csv,/0\.23/); assert.match(csv,/0\.12/);
  assert.equal(X.AuditLedger.csvCell('method, with \"quotes\"\nand newline'), '\"method, with \"\"quotes\"\"\nand newline\"');
  assert.equal(X.AuditLedger.csvCell('=1+1'), "'=1+1");
});
await test('audit ledger rejects invalid backtests and missing datasets', () => {
  assert.throws(()=>X.AuditLedger.createCSV({result:{valid:false,trades:[]},h1:{candles:[]},m15:{candles:[]}}),/valid completed backtest/);
  assert.throws(()=>X.AuditLedger.createCSV({result:{valid:true,trades:[],parameters:{},method:'test'},h1:null,m15:{candles:[]}}),/Both H1 and M15/);
  assert.throws(()=>X.AuditLedger.createCSV({result:{valid:true,trades:[{status:'OPEN_AT_DATA_END',side:'BUY'}],parameters:{},method:'test'},h1:{candles:[]},m15:{candles:[]}}),/complete, valid closed/);
});
await test('backtester summary computes expectancy and drawdown from closed trades', () => {
  const s = X.Backtester.summarize([{netR:2},{netR:-1},{netR:1}]);
  assert.equal(s.closedTrades,3); assert.equal(s.winRatePercent,66.66666666666666); assert.equal(s.netR,2); assert.equal(s.expectancyR,2/3); assert.equal(s.maxDrawdownR,1);
});
process.stdout.write(`\n${passed} tests passed.\n`);
}
main().catch(error => { console.error(error); process.exitCode = 1; });
