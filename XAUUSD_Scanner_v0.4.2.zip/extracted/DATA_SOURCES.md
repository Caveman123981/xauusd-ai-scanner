# XAUUSD data-source assessment — checked 2026-11-10

## Decision

**Use AlgoSpecial's free OHLC preview only for historical development/backtesting. Do not treat it as a live feed or as the user's broker's exact prices.** The app now has an optional no-key CSV fetcher for H1 and M15. The adapter validates the provider's CSV through the same strict candle validator used for manual imports.

A reliable, free, broker-comparable live H1/M15 XAUUSD OHLC source has **not** yet been verified. Keep live-data integration open; do not claim that the scanner is live.

## Candidates

### 1. AlgoSpecial — selected for historical research only

- Official guide: https://www.algospecial.com/data-api/xauusd/
- API overview: https://www.algospecial.com/data-api/
- Quality report: https://www.algospecial.com/historical-data/data-quality/xauusd-m15/
- No API key; CORS-enabled browser requests.
- XAUUSD timeframes include M1, M5, M15, M30, H1, H4, D1, W1 and MN1.
- Free preview: maximum 31 calendar days and 2,000 rows per request; 60 requests/minute and 1,000/day per IP.
- Published M15 coverage: 2017-01-19 to 2026-10-30; 225,077 rows.
- Published M15 quality report: 97/100, Grade A, zero duplicates and OHLC violations; it still reports 2,942 gaps, 1,364 zero/missing spread rows, 19 flat bars and 6 invalid weekend bars.
- Prices are three-decimal on an Exness-style source feed. Timestamps are broker server time, not UTC.
- Terms say research, backtesting and commercial applications are allowed; no standalone resale/redistribution; data is as-is and should be checked against the user's broker.
- The free API preview is not full historical access and the documented dataset currently ends 2026-10-30. It cannot supply a live current signal.

### 2. XAUS — possible spot cross-check; not selected as primary candle feed

- API: https://xaus.com/api/
- About/methodology: https://xaus.com/about/
- Free, no API key, CORS open. Spot endpoint is edge-cached around 60 seconds and carries explicit freshness/staleness metadata.
- Spot data is an indicative mid-market reference, not a tradable bid/ask quote.
- First-party intraday points are sampled every five minutes, with at most 48 hours requested and 14-day retention; this is insufficient alone for a 200-period H1 EMA.
- The chart endpoint documents 15-minute bars for up to five days and 1-hour bars for up to three months, but its chart series is a Yahoo Finance proxy and the site notes a spot-pair / gold-futures fallback in its historical series. Exact instrument mapping and broker comparability must be tested before use.
- Candidate for a secondary spot sanity check after runtime testing; not approved as a trading-grade source.

### 3. Goldprice.dev — not sufficient on Free

- Docs: https://goldprice.dev/docs/historical
- Free includes daily XAU/USD history for the latest 30 days and 15-minute-delayed spot prices, but no intraday bars. 1h/4h bars require Plus; 1m–4h bars require Pro.

### 4. Alpha Vantage — not sufficient for H1/M15 candles

- Docs: https://www.alphavantage.co/documentation/
- Gold spot endpoint provides a spot quote; gold history supports daily, weekly and monthly intervals. It does not provide the required intraday gold OHLC series in the documented gold endpoints.

### 5. Twelve Data — not included in the free Basic plan for this commodity

- Pricing: https://twelvedata.com/pricing
- XAU/USD is catalogued as a Commodity Aggregate, not an ordinary forex pair. The commodity market page indicates Grow+ access, while Basic's listed coverage is real-time US equities/ETFs, forex and crypto. Do not assume free Basic includes XAU/USD commodity intraday data.

### 6. Gold API — free OHLC quota/aggregation limitations

- Pricing: https://gold-api.com/pricing
- Free includes 10 requests/hour shared by history or OHLC; minute/hour aggregation and unlimited OHLC access are listed under the $10/month Premium plan. Not selected under the $0 constraint.

### 7. Standard Bullion — useful reference price, not OHLC candles

- API: https://standardbullion.com/gold-price-api
- Free, CORS-open feed includes bid/ask and a 15-minute intraday price history. Its history response is price points rather than full OHLC bars, so it is not sufficient by itself for ATR and OHLC-based strategy testing.

## Implementation guardrails

- The AlgoSpecial connector is explicitly labeled historical-only in the UI.
- Preserve the provider's timestamp string and do not treat its broker clock as UTC for session logic.
- Preserve tick volume and spread points when present; do not interpret zero spread as a valid tradable spread.
- Validate timestamps, duplicates, ordering and OHLC ranges locally even if the provider publishes a high quality score.
- Compare the feed's price, digits, spread, session times and missing-bar behavior with the user's own broker before any trading-related use.
- Never substitute daily/spot quotes for missing intraday candles or synthesize OHLC candles from a single sampled price.

## Timestamp handling update (v0.3.5)
- The parser rejects timezone-naive ISO date-times; import ISO timestamps with `Z` or an explicit offset.
- MetaTrader `YYYY.MM.DD HH:MM[:SS]` timestamps are treated as broker-server wall-clock values, not UTC. Their numeric representation is only a stable ordering surrogate.
- A CSV cannot mix broker wall-clock and absolute timestamp forms, and H1/M15 imports with different timestamp bases are rejected. This still does not verify that two feeds share the same broker clock, timezone, daylight-saving policy or session calendar.
