# XAUUSD AI Scanner — v0.4.2 development build

## What this build is
A mobile-friendly, local browser prototype for analyzing imported XAUUSD H1 and M15 candle CSV files. It is **analysis-only** and does not connect to a broker, fetch live prices, or place orders.

## What's new in v0.4.2
- Added elapsed-exposure lower/upper bounds for closed and unresolved simulated positions, separately from observed-bar holding counts. OHLC intrabar stop/target exits receive a 15-minute uncertainty window; bar-open gap exits and modelled bar-close time exits receive a single modelled duration.
- Added exit-timing precision labels and included elapsed-exposure fields in audit CSV rows. These are timestamp-derived diagnostics only; entry/exit/holding rules and performance calculations are unchanged. Broker-server timestamp differences are not asserted to be UTC.

## What's new in v0.4.1
- Added deterministic M15 timestamp-grid coverage diagnostics for the full backtest dataset and separately for the terminal holdout: observed rows, grid slots, gap count, missing interval slots, largest observed gap and elapsed window.
- Explicitly labels the coverage percentage as timestamp-grid coverage, not market-open coverage, because the tool cannot distinguish market closures from missing provider rows.

## What's new in v0.4.0
- Clarified holdout boundaries: the test window is the final chronological row segment, no post-test candles are passed into trade simulation, and trades still open at the last test candle are reported unresolved and excluded from closed-trade metrics.
- Enforced the existing one-open-position-at-a-time assumption when a trade remains unresolved at dataset end; later overlapping entries are no longer evaluated.

## What's new in v0.3.8
- H1 and M15 candle spacing must be integer multiples of their timeframe duration. Legitimate session/data gaps remain allowed and are reported; irregular sub-interval spacing is rejected.
- H1 candle opens must fall on the M15 interval grid, without assuming UTC hour boundaries or a particular broker timezone.
- The backtester independently enforces these interval/alignment rules even if a caller supplies forged validation flags.
- Added six regression tests covering irregular spacing, legitimate gaps, non-hour-offset timestamp phases and independent backtester rejection. Full suite at that release: 48 tests.

## What's new in v0.3.7
- Backtest signals are now entered only at the immediately following M15 bar open. A candidate is skipped if the next observed M15 candle starts later than the signal candle's scheduled close; this avoids entering stale signals after missing intervals or market-session gaps. Results expose `skippedGapEntries`.
- Maximum holding bars counts observed M15 candles, not wall-clock elapsed time; gaps may extend elapsed holding time.

## What's new in v0.3.6
- Scanner signals now use only an M15 candle whose completion is evidenced by a subsequent candle opening at or after its scheduled 15-minute close. The final CSV row is never treated as closed merely because it is the last available row.
- H1 trend context is filtered against the close time of that selected, confirmed M15 signal candle, preventing an unconfirmed M15 row from advancing the H1 completion boundary.
- If fewer than 30 confirmed M15 candles remain, the scanner fails closed with WAIT and a clear data rejection. The UI reports the selected signal candle and confirmed-versus-loaded counts.
- Completion is inferred from candle sequence timestamps, not the device clock; broker-server wall-clock timestamps are not compared with local UTC.
- Added three regression tests for final-row exclusion, insufficient confirmed history, and gap/short-interval selection. Full suite: 41 tests.

## What's new in v0.3.5
- Timestamp parsing now rejects timezone-naive ISO/local date-times, which could otherwise shift depending on the device timezone. ISO imports must include `Z` or an explicit offset; Unix epoch and MetaTrader broker-clock formats remain supported.
- CSV datasets record whether timestamps are absolute instants or broker-server wall-clock values. Mixed timestamp bases within a CSV, or between H1 and M15 datasets, are rejected. Broker-clock timestamps are encoded as pseudo-UTC numbers strictly for interval ordering; this does not convert them to UTC or establish the broker's timezone.
- Added four regression tests for timezone-naive input, explicit offsets, mixed bases, and cross-timeframe basis mismatch.

## What's new in v0.3.4
- Added a reproducible CSV audit export for historical backtest runs. The file includes one run-metadata row and one row per closed trade, with stable IDs, timestamps, execution assumptions, price levels, R-multiples, cost breakdowns, strategy settings and source dataset ranges.
- Export is disabled until a valid backtest completes and is invalidated when the source datasets change. The ledger records each dataset's declared timestamp basis. The ledger is not a broker statement and does not include a cryptographic data fingerprint.

## What's new in v0.3.3
- Backtester now independently validates H1/M15 timestamp order and positive, internally consistent OHLC values, even when callers supply forged `validation.valid` flags.
- Standalone trade simulation also rejects malformed execution candles.
- Added three regression tests for invalid timestamp order, malformed OHLC and execution-bar integrity.

## What's new in v0.3.1
- Added a chronological 70/30 out-of-sample holdout evaluator. Earlier M15 candles are retained only for indicator/H1 warm-up; signal generation is gated to the final 30%. No parameter fitting is performed. The holdout must not be repeatedly reused for tuning.
- Added a dedicated mobile UI panel for the holdout report.

## What's new in v0.3.0
- Added an event-driven historical backtester with next-M15-open entries, completed-H1-only context, separate explicit round-trip spread, commission and slippage cost inputs, max holding period, conservative stop-first handling when stop and target touch in the same OHLC candle, and R-based performance statistics.
- Added strict rejection of impossible MetaTrader calendar dates.
- Scanner excludes incomplete H1 candles from trend analysis.
- Fixed the Node test runner to await asynchronous provider tests before reporting results.

## What's new in v0.2.1
- Added an optional no-key AlgoSpecial historical XAUUSD H1/M15 CSV fetcher (free preview only; capped at 31 days and 2,000 rows).
- Preserved optional tick-volume and spread-point fields from provider exports.
- Split the scanner into deterministic modules: Data Integrity, Market Analyst, Signal Analyst, Risk Analyst, Quality Reviewer, and Orchestrator.
- Strict CSV parsing with timestamp, chronological-order, duplicate, positive-price, and OHLC-range validation.
- Gap warnings instead of silently skipping suspicious rows.
- H1 EMA 20/50/200, M15 EMA20, RSI14, and ATR14 calculations.
- Explicit fail-closed orchestration: invalid data or reviewer/risk failures produce WAIT.
- Position sizing floors to broker lot step and rejects risk above 1%.
- Mobile layout and visible distinction between historical CSV analysis and live data.

## Important architecture truth
The five "agents" in v0.2.1 are **software modules with deterministic responsibilities**, not separate LLMs or autonomous AI services. This keeps calculations reproducible and fits the $0 constraint. LLM-based interpretation/review can be evaluated later, but it must never invent prices or override deterministic risk/data gates.

## Run
Open `index.html` in a modern browser. Keep the `src` folder beside it. No build step or paid service is required.

## CSV format
Required headers (case-insensitive): `time,open,high,low,close`.
- `time` may be ISO-8601 with `Z` or an explicit `±HH:MM` offset, MetaTrader `YYYY.MM.DD HH:MM[:SS]` broker-clock text, Unix seconds, or Unix milliseconds. ISO date-times without a timezone are rejected to avoid device-timezone-dependent parsing. Do not mix broker-clock and absolute timestamps in one dataset or across H1/M15.
- CSV parsing requires at least 210 H1 rows and 30 M15 rows. For scanning, at least 30 demonstrably completed M15 candles are required; with regular 15-minute timestamps, this normally means importing at least 31 M15 rows so a later row confirms the 30th candle close.
- Candles must be chronological, unique, have valid OHLC ranges, and be spaced by integer multiples of their timeframe duration. Irregular sub-interval spacing is rejected.
- H1 candle opens must align to the M15 interval grid. No UTC hour-boundary assumption is made; the broker/timezone phase is not inferred.
- Legitimate session/data gaps remain allowed and are reported as warnings; they still require inspection.

## Experimental strategy hypothesis
- H1 bullish: close > EMA50, EMA20 > EMA50 > EMA200. Bearish is inverse.
- M15 BUY: H1 bullish, close > EMA20, RSI14 in [50,70], close > previous high.
- M15 SELL: H1 bearish, close < EMA20, RSI14 in [30,50], close < previous low.
- Otherwise WAIT.
- Indicative stop = 1.5 × M15 ATR14; target = 2 × stop distance.

These are unvalidated defaults, not a proven edge. The backtester is now available, but no real-market performance claim, out-of-sample test, broker-specific validation, or forward test has been established.

## Backtesting notes (v0.4.0)
- H1/M15 alignment is checked by requiring each H1 open to lie on the M15 15-minute grid, while each timeframe internal interval must be an integer multiple of its expected duration. This supports non-hour-offset timestamp phases without assuming UTC or a broker timezone. Gaps remain allowed but are surfaced; irregular sub-interval spacing is rejected.
- Signals are evaluated after an M15 candle closes; entry is at the immediately following M15 candle open. If the next observed row is later than 15 minutes after the signal candle open, the candidate is skipped and counted in `skippedGapEntries`.
- Scanner signals use the latest M15 bar confirmed complete by a subsequent candle timestamp at or beyond its scheduled 15-minute close. The final row is excluded because no later row confirms its close. H1 bars are only used after their full 60-minute interval has elapsed by the selected M15 signal close. Timestamps are assumed to be candle-open times.
- Stop/target are recalculated from the actual next-bar entry price using the signal candle ATR distance.
- If a candle touches both stop and target, stop is assumed first because OHLC cannot identify intrabar order.
- Trades still open at the end of the dataset are excluded from closed-trade statistics.
- Enter separate estimated round-trip spread, commission and slippage costs in XAU price units. The values are added together; zero excludes that component. They are not converted from broker points, lots or account currency, and must be calibrated externally.
- Results are reported in R multiples, not account currency. The current backtester does not model swaps, partial fills, variable spread, tick-level execution or broker-specific contract details.
- This is an initial research tool, not evidence of a profitable strategy. No parameter optimization or broker-specific validation has been completed. v0.3.1 adds a single chronological holdout evaluation, but no real-data holdout result has yet been established.

## Test
Run with Node.js 18+:

```bash
node tests/run-tests.js
```

## Data source assessment
See `DATA_SOURCES.md` for the current provider comparison. AlgoSpecial is selected for historical research only; a reliable free live H1/M15 XAUUSD feed remains unresolved.

## Elapsed exposure diagnostics (v0.4.2)
- `barsHeld` remains the count of observed M15 candles. `elapsedExposureLowerBoundMinutes` and `elapsedExposureUpperBoundMinutes` describe a timestamp-derived interval, not an exact fill time.
- Gap exits are modelled at the next candle open; time exits are modelled at the final candle close. Intrabar stop/target exits have an open-to-close 15-minute uncertainty window because OHLC data cannot identify the touch time.
- Unresolved positions span the entry candle open through the last observed candle close. Timestamp differences preserve the dataset's encoded time basis and are not claimed to be UTC. These fields do not affect trade outcomes or metrics.

## Out-of-sample holdout notes (v0.4.0)
- Default split is chronological 70% warm-up/history and final 30% test. All earlier candles remain available to indicator calculations, but strategy signals are generated only from the test boundary onward.
- No parameter fitting or optimization is performed on the first segment. The holdout is a one-time diagnostic, not a walk-forward study or proof of robustness. If the strategy is changed after viewing results, the holdout is contaminated and a fresh untouched period is required.
- Test window is the final chronological row segment. Signals before the split are excluded; the first possible test entry follows a signal on a test-window candle. No candles after the final test row are available to simulation. A trade still open at the final test candle is counted unresolved, excluded from closed-trade metrics, and blocks subsequent entries under the one-open-position-at-a-time model.

## Known limitations / next work
1. No live or streaming market data; source/provider research and terms review are still required.
2. The v0.3.4 backtester is a first OHLC-based event simulation; it does not yet model dynamic spread, broker commission conversion, swaps, partial fills, or tick-level execution. Cost inputs are static user estimates. A single chronological holdout exists, but repeated walk-forward validation remains outstanding.
3. The new CSV ledger is a manual export, not a persistent audit database or versioned signal service; it records closed backtest trades and separately labeled unresolved end-of-data positions; unresolved rows are not closed trades or performance results.
4. No LLM agent runtime; role modules are deterministic.
5. Position-size output requires the user's broker-specific contract value and lot rules.
6. Broker-server wall-clock timestamps are only pseudo-UTC encoded for ordering; the actual offset, daylight-saving rules and session calendar are not modeled. H1/M15 basis mismatches are rejected, but same-basis data can still come from different brokers or clocks; source comparability must be checked externally.
7. Freshness against a live clock is not enforced because this build analyzes imported snapshots; scanner excludes unconfirmed final M15 rows and H1 candles whose full hour has not elapsed by the selected confirmed M15 close.

## Safety
Never use this prototype to place live trades. It is not investment advice and does not demonstrate profitability. The scanner must remain separate from the MT5 EA and must never execute orders.


### Unresolved-position audit records (v0.4.0)

A position still open at the end of available data is exported as a distinct `UNRESOLVED_POSITION` audit row, not as a closed `TRADE`. The row records side, entry price/time, stop/target, bars held, and last observed candle/time/close. It deliberately contains no exit price, realized R, or closed-trade performance contribution. The run metadata records the unresolved-position count.
