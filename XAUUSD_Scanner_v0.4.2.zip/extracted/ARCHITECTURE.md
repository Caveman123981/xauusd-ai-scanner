# XAUUSD Scanner v0.4.2 — module contracts

## Pipeline

`CSV import → Data Integrity → Market Analyst → Signal Analyst → Risk Analyst → Quality Reviewer → Orchestrator decision`

The orchestrator returns `WAIT` immediately if dataset validation fails. Any critical review issue or invalid risk assessment also prevents BUY/SELL from reaching the final output.

## Completed-bar selection (v0.3.6)

- Scanner candle timestamps are treated as candle-open times. The latest M15 signal bar is the newest row for which a subsequent row opens at or after the 15-minute scheduled close. The last row cannot confirm itself and is excluded.
- The scanner requires at least 30 demonstrably completed M15 bars. Otherwise it returns `WAIT` with `DATA_REJECTED`.
- H1 trend bars are filtered against the close time of the selected confirmed M15 signal bar, not the final imported M15 row.
- Completion is inferred only from sequence timestamps. The implementation deliberately does not compare broker-server wall-clock timestamps with the device clock because the broker timezone/offset is unknown.
- This is a conservative sequence-based completion check, not proof that the provider's timestamps or candle contents are accurate.

## Module responsibilities and contracts

### Historical data adapter (`src/algospecial-provider.js`)
- Optional no-key fetcher for AlgoSpecial XAUUSD H1/M15 historical CSV preview.
- Enforces the published 31-calendar-day and 2,000-row preview limits before accepting data.
- Labels all fetched data historical-only, preserves broker-server time basis, and routes data through local validation.
- Does not provide live data or prove that prices match the user's broker.

### Data Integrity (`src/data-integrity.js`)
- Accepts Unix epoch, ISO-8601 with explicit `Z`/offset, and MetaTrader broker-server wall-clock formats. Rejects timezone-naive ISO/local date-times to prevent device-timezone-dependent parsing.
- Returns dataset-level `timestampBasis` (`absolute` or `broker_server_wall_clock`); mixed bases inside a CSV or between H1/M15 datasets are rejected. Broker-clock values are pseudo-UTC encoded only for interval arithmetic and are never claimed to be UTC.
- Input: CSV text plus timeframe (`H1` or `M15`).
- Output: `{ candles, validation }` where each candle has `time`, `timestamp`, `open`, `high`, `low`, `close`.
- Rejects: missing required columns, invalid timestamps, non-positive/non-finite prices, inconsistent OHLC, duplicate timestamps, and out-of-order rows.
- Enforces that every timestamp delta is an integer multiple of the expected timeframe duration; irregular sub-interval spacing is rejected while multi-interval session/data gaps remain allowed.
- Cross-timeframe gate: every H1 open must fall on the M15 interval grid. This avoids assuming UTC hour boundaries or a known broker timezone.
- Warns when gaps are present; a gap can reflect a market closure or missing candles and must be inspected.
- Dataset gate: at least 210 H1 candles and 30 M15 candles; H1 snapshot must not end after M15 snapshot.

### Market Analyst (`src/market-analyst.js`)
- Input: validated H1 candles.
- Output: `BULLISH`, `BEARISH`, or `NEUTRAL`, plus EMA20/50/200 and latest close.
- This is a deterministic trend classifier, not an LLM.

### Signal Analyst (`src/signal-analyst.js`)
- Input: validated M15 candles and H1 market context.
- Output: candidate `BUY`, `SELL`, or `WAIT`, indicator values and explicit rule reasons.
- It cannot override the Data Integrity gate.

### Risk Analyst (`src/risk-analyst.js`)
- Input: signal candidate, ATR, reference close and bounded configuration.
- Output: stop/target geometry or validation errors.
- Position sizing requires broker-specific USD P/L per $1 gold move per 1.00 lot, minimum lot, lot step and max lot. It floors size to the lot step; it does not round risk upward.
- Maximum configured risk is capped at 1% in this prototype; default is 0.5%.

### Quality Reviewer (`src/quality-reviewer.js`)
- Input: data, market, signal and risk outputs.
- Output: `PASS` or `REJECT` with explicit issues.
- Checks trend/signal consistency, indicator availability, risk validity and stop/target direction.

### Orchestrator (`src/orchestrator.js`)
- Runs the stages in order and creates the final result.
- Fails closed to `WAIT` if data fails validation or review/risk gates do not pass.
- Does not execute orders or access accounts.

## Trust boundaries

- Numeric calculations and gates belong in deterministic code.
- AI/LLM components are not implemented in this version. If added later, they may explain evidence or challenge assumptions but may not invent prices, recalculate authoritative risk values, bypass data validation, or authorize execution.
- The current input is a user-provided CSV snapshot. No live feed, candle freshness validation, broker session calendar, or current quote is available.
- A final BUY/SELL is only a historical rule match on the last imported candle, not a current actionable trade recommendation.


## Backtest gap handling (v0.4.0)
- A candidate generated at an M15 bar close is eligible for entry only when the next row opens exactly one M15 interval (15 minutes) after that signal bar's open timestamp.
- If the next observed row is later, the candidate is counted in `skippedGapEntries` and no delayed entry is simulated. This avoids treating a signal from before a missing interval or market closure as if it were a fresh next-bar signal.
- `maxHoldingBars` remains a count of observed M15 candles, not elapsed wall-clock time. A session/data gap can extend the actual elapsed duration before a time exit; stop/target gaps are handled at the next observed candle open.

## Historical Backtester (v0.3.0)
- Input: H1/M15 datasets already parsed and validated by Data Integrity.
- Event sequence: each M15 signal is computed only after that bar closes; entry is at the immediately following M15 open. If the next observed candle is delayed by a missing interval/session gap, the candidate is skipped and counted.
- H1 context: only bars with `H1 open timestamp + 60 minutes <= M15 signal close time` are visible. This assumes timestamps identify candle opens.
- Exit: ATR-derived stop and fixed reward/risk target; gap opens fill at the open; if stop and target are both touched in one OHLC candle, stop is assumed first.
- Costs: caller supplies separate estimated round-trip spread, commission and slippage costs in XAU price units; they are summed, and zero excludes that component. The legacy aggregate cost remains additive for API compatibility. No conversion from broker spread points, lots or account currency is performed; no dynamic spread or swap model exists.
- Output: closed trades, wins/losses, win rate, net R, expectancy, profit factor and max drawdown in R. Open trades at dataset end are excluded from closed-trade metrics.
- Limitations: no tick-level path, variable spread, swaps, partial fills, broker contract conversion, optimization, or out-of-sample/walk-forward report yet.


## Trade audit ledger (v0.3.5)

`src/audit-ledger.js` serializes a valid completed backtest into deterministic CSV. It writes a `RUN_METADATA` row even when there are no closed trades, followed by ordered `TRADE` rows. Trade IDs are deterministic within a run and combine the entry candle timestamp (or a documented fallback) with the row sequence. Fields include timestamps, prices, exit reason, gross/net/cost R, round-trip cost components, fixed strategy parameters, release/method labels, and H1/M15 dataset counts, time ranges and declared timestamp bases. CSV cells are escaped for commas, quotes and line breaks. The ledger does not calculate a cryptographic dataset hash, infer broker identity, or represent actual broker fills. The browser export is invalidated when the source data changes.


## Holdout boundary policy (v0.4.0)
- The single holdout is the final chronological M15 row segment `[splitIndex, lastIndex]`; pre-split M15 candles remain indicator warm-up only, and signal evaluation starts at `splitIndex`.
- H1 context is still admitted only when the complete H1 interval ends by the signal candle close.
- Entry remains the immediately following M15 open. No candles after the final holdout row are passed to trade simulation.
- Positions unresolved at the final available test candle are excluded from closed-trade metrics and block later signals, preserving the one-open-position-at-a-time model. The count is reported as `unresolvedSignals`.
- This is still one terminal holdout, not walk-forward validation; it cannot measure generalization to future data beyond the imported sample.


### Unresolved-position audit semantics (v0.4.0)

End-of-data positions are surfaced separately from closed trades. They remain excluded from closed-trade statistics and have no realized return/exit fields. Audit exports may contain `UNRESOLVED_POSITION` rows with entry and last-observed details; consumers must not treat these as completed trades.


## M15 timestamp-grid coverage diagnostics (v0.4.1)
- `measureM15Coverage` reports observed candles, elapsed window, expected 15-minute grid slots, timestamp gaps, inferred missing grid slots, largest inter-row gap, and observed/grid-slot percentage.
- Holdout coverage is calculated only on `[splitIndex, lastIndex]`; full backtest coverage describes the complete imported M15 dataset.
- This is a timestamp-grid diagnostic, not market-session coverage. Without a broker session calendar and reliable source metadata, a gap cannot be classified as a market closure versus missing provider data. It must not be used as an uptime score or adjusted performance metric.
- `maxHoldingBars` remains observed-candle based; this change adds descriptive coverage only and does not alter entries, exits, or holding rules.


## Elapsed exposure diagnostics (v0.4.2)
- Observed-bar holding (`barsHeld`) remains unchanged and is not a wall-clock duration.
- Closed trades report elapsed exposure lower/upper bounds. Bar-open gap exits use a single bar-open duration; modelled time exits use a single bar-close duration; intrabar stop/target exits use the exit candle open-to-close window because OHLC cannot identify the touch time.
- Unresolved positions report a range from entry candle open to last observed candle open/close.
- Audit CSV includes the bounds and `exit_timing_precision`. Timestamp deltas use the imported timestamp basis; broker-server wall-clock values are not promoted to UTC. No strategy, exit, or performance calculation changes.
