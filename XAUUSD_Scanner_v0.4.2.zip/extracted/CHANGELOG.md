## v0.4.2 — 2026-11-10
- Added timestamp-derived elapsed-exposure lower/upper bounds for closed and unresolved positions, kept separate from observed M15 bar counts.
- Added exit timing precision labels: bar-open gap, modelled bar-close time exit, intrabar unknown, and unresolved last-bar interval. OHLC intrabar exits are bounded by the exit candle open/close rather than assigned a fabricated exact timestamp.
- Added elapsed exposure fields to closed and unresolved audit CSV rows; documented that timestamp basis is preserved and not necessarily UTC.
- Added two regression tests covering intrabar, gap, time-exit and unresolved exposure semantics; full suite: 54 tests.

# Changelog

## v0.4.1 — 2026-11-10
- Added M15 timestamp-grid coverage diagnostics: observed candles, expected grid slots, gap count, inferred missing interval slots, largest gap, elapsed window and grid coverage percentage.
- Holdout coverage is measured strictly within the final test segment, separately from the full imported dataset.
- Documented that timestamp gaps cannot be classified as market closures or missing provider data without a broker session calendar; no strategy or holding rule changed.
- Added regression tests for gap arithmetic and holdout-only measurement.

## v0.3.9 — 2026-11-10
- Made the terminal 70/30 holdout boundary explicit in result metadata and mobile reporting, including test end timestamp/index and a documented boundary policy.
- Confirmed that the test period is the final row segment; no post-test candles are available to simulation, and positions unresolved at the final test candle are excluded from closed-trade metrics.
- Fixed unresolved-position overlap: once a trade remains open through dataset end, later signal evaluation stops, preserving the one-open-position-at-a-time assumption.
- Added a focused regression test; full suite now contains 49 tests.



## v0.3.8 — 2026-11-10
- Enforced integer-multiple candle spacing for H1 and M15; irregular sub-interval timestamp spacing now fails validation while legitimate multi-interval market/session gaps remain allowed and warned.
- Added cross-timeframe alignment validation: H1 candle opens must lie on the M15 interval grid, without assuming UTC hour boundaries or broker timezone.
- Applied the same interval/alignment checks independently inside the backtester so forged `validation.valid` flags cannot bypass them.
- Added six regression tests for irregular spacing, valid gaps, non-hour-offset timestamp phases and backtester validation. Full suite: 48 tests.

## v0.3.7 — 2026-11-10
- Backtester now skips BUY/SELL candidates when the next observed M15 candle does not open exactly 15 minutes after the signal candle, preventing stale signals from being entered after missing bars or session gaps.
- Added `skippedGapEntries` to backtest results and clarified that max holding bars counts observed candles, so elapsed time may stretch across data/session gaps.
- Added a regression test for a candidate followed by a missing M15 interval.


## v0.3.6 — 2026-11-10
- Scanner now selects only M15 candles whose close is evidenced by a subsequent candle timestamp at or after the scheduled 15-minute close; the final imported row is never assumed complete.
- H1 context is limited to bars fully closed by the selected confirmed M15 signal candle's close.
- Fail closed when fewer than 30 confirmed M15 candles are available; UI reports completed/loaded counts and selected signal candle time.
- Avoided device-clock comparisons for broker-server wall-clock timestamps. Added three regression tests; full suite: 41 tests.

## v0.3.4 — 2026-11-10
- Added a deterministic trade-audit CSV ledger with run-metadata and closed-trade rows, stable trade IDs, signal/entry/exit timestamps, prices, exit reasons, R-multiples, and separate cost components.
- Included strategy settings, scanner release, backtest method, and H1/M15 dataset counts and date ranges; explicitly does not claim a cryptographic fingerprint or broker execution record.
- Added mobile browser CSV download and disabled stale exports whenever source data changes or a backtest fails.
- Added three audit-ledger regression tests; full suite now contains 34 tests.


## v0.3.3 — 2026-11-10
- Split user-estimated round-trip costs into spread, commission and slippage inputs, each explicitly denominated in XAU price units.
- Preserved the legacy aggregate `roundTripCostPrice` API as an additive compatibility field.
- Added per-trade cost breakdown and total cost metadata; invalid negative/non-finite components are rejected.
- Updated mobile backtest and holdout controls to accept separate cost components.
- Added two cost-model regression tests; costs are still estimates, not broker-derived execution data.


## v0.3.2 — 2026-11-10
- Added independent backtester validation of candle timestamps, ordering, positive OHLC values and internal OHLC consistency; this prevents forged validation flags from bypassing core checks.
- Added execution-candle validation to standalone trade simulation.
- Added three regression tests; full suite now contains 29 tests.


## v0.3.1 — 2026-11-10
- Added a chronological 70/30 out-of-sample holdout evaluator; indicator warm-up may use the earlier history but signals are gated to the test period.
- Added a mobile UI report for the holdout test and an explicit warning against repeated tuning on the same holdout.
- Added tests for invalid split fractions and strict chronological signal gating.

## v0.3.0 — 2026-11-10
- Added an event-driven OHLC historical backtester with next-M15-open entry and completed-H1-only trend context to avoid H1 look-ahead.
- Added stop/target gap handling, conservative stop-first handling when both levels touch in one bar, maximum holding bars, unresolved-at-data-end handling, and explicit round-trip cost input.
- Added R-based closed-trade metrics: win rate, expectancy, profit factor and maximum drawdown.
- Added a mobile UI backtest panel and explicit modelling assumptions.
- Excluded incomplete H1 candles from the current scanner trend context.
- Rejected impossible MetaTrader calendar dates.
- Corrected the asynchronous Node test harness to await all tests before reporting completion.
- Added seven backtester tests; full suite now contains 24 tests.


## v0.2.1 — 2026-11-10
- Added optional no-key AlgoSpecial historical XAUUSD H1/M15 fetcher (31-day / 2,000-row preview cap); clearly labeled historical-only.
- Preserved provider tick volume and spread points, and accepted `Timestamp` headers.
- Added data-source assessment documenting limitations and unresolved live-feed gap.
- Reorganized the prototype into six deterministic modules and a central orchestrator.
- Added strict CSV/time/OHLC validation, duplicate/out-of-order rejection, and candle-gap warnings.
- Added a minimum-history and timeframe-alignment gate.
- Added independent consistency review and fail-closed WAIT behavior.
- Added broker lot-step flooring and a 1% maximum risk input guard.
- Updated mobile UI and made historical-CSV/no-live-feed limitations explicit.
- Added 15 Node.js tests covering indicators, parsing, validation, risk sizing, fail-closed behavior and an end-to-end synthetic BUY case.

## v0.1 — prior prototype
- Single-page CSV import, EMA/RSI/ATR, experimental signal conditions, indicative stop/target and position-size calculator.
- No live data or validated backtesting.

## v0.3.5
- Reject timezone-naive ISO timestamps; require `Z` or explicit offset for absolute ISO date-times.
- Track absolute versus broker-server wall-clock timestamp basis and reject mixed bases within/across timeframe datasets.
- Clarify that MetaTrader wall-clock values are pseudo-UTC encoded for ordering only, not converted to UTC.
- Add four timestamp-basis regression tests.

## v0.4.0
- Added explicit unresolved-position detail to backtest results and UI: side, entry price/time, last observed candle/time/close, and observed bars held.
- Bumped audit ledger schema to 1.2 and added separate `UNRESOLVED_POSITION` audit CSV records and unresolved count in run metadata; unresolved positions remain distinct from closed `TRADE` rows and are excluded from closed-trade performance metrics.
- Added regression coverage for unresolved audit serialization and distinction from closed trades.
