(function (root) {
  function validateOHLCSeries(candles, label, requireTimestamps = true) {
    const errors = [];
    if (!Array.isArray(candles) || candles.length === 0) return [`${label} candles must be a non-empty array.`];
    let previousTimestamp = -Infinity;
    for (let i = 0; i < candles.length; i++) {
      const c = candles[i];
      if (requireTimestamps) {
        if (!c || !Number.isFinite(c.timestamp) || c.timestamp <= previousTimestamp) errors.push(`${label} candle ${i + 1} has a missing, invalid, duplicate or out-of-order timestamp.`);
        else previousTimestamp = c.timestamp;
      }
      if (!c || !['open', 'high', 'low', 'close'].every(k => Number.isFinite(c[k]) && c[k] > 0)) { errors.push(`${label} candle ${i + 1} has invalid positive OHLC values.`); continue; }
      if (c.high < c.low || c.high < Math.max(c.open, c.close) || c.low > Math.min(c.open, c.close)) errors.push(`${label} candle ${i + 1} has inconsistent OHLC values.`);
    }
    return errors;
  }

  function simulateTrade({ side, entryPrice, stopDistance, rewardRisk = 2, candles, startIndex, maxHoldingBars = 96, roundTripCostPrice = 0, spreadCostPrice = 0, commissionCostPrice = 0, slippageCostPrice = 0 }) {
    if (!['BUY', 'SELL'].includes(side) || !Array.isArray(candles) || !Number.isInteger(startIndex) || startIndex < 0 || startIndex >= candles.length) return { status: 'INVALID', error: 'Invalid trade inputs.' };
    const candleErrors = validateOHLCSeries(candles, 'Execution', false);
    if (candleErrors.length) return { status: 'INVALID', error: candleErrors[0] };
    if (![entryPrice, stopDistance, rewardRisk, roundTripCostPrice, spreadCostPrice, commissionCostPrice, slippageCostPrice].every(Number.isFinite) || entryPrice <= 0 || stopDistance <= 0 || rewardRisk < 1 || [roundTripCostPrice, spreadCostPrice, commissionCostPrice, slippageCostPrice].some(x => x < 0) || !Number.isInteger(maxHoldingBars) || maxHoldingBars < 1) return { status: 'INVALID', error: 'Trade prices, risk, costs or holding limit are invalid.' };
    const costBreakdown = { legacyAggregate: roundTripCostPrice, spread: spreadCostPrice, commission: commissionCostPrice, slippage: slippageCostPrice };
    const totalRoundTripCostPrice = Object.values(costBreakdown).reduce((sum, value) => sum + value, 0);
    const sign = side === 'BUY' ? 1 : -1;
    const stopLoss = entryPrice - sign * stopDistance;
    const takeProfit = entryPrice + sign * stopDistance * rewardRisk;
    if (stopLoss <= 0 || takeProfit <= 0) return { status: 'INVALID', error: 'Stop or target is not a positive price.' };
    const lastIndex = Math.min(candles.length - 1, startIndex + maxHoldingBars - 1);
    for (let i = startIndex; i <= lastIndex; i++) {
      const c = candles[i];
      let exitPrice = null, exitReason = null;
      // Gaps at the bar open are filled at the open, not at the stale stop/target price.
      if (side === 'BUY' && c.open <= stopLoss) { exitPrice = c.open; exitReason = 'STOP_GAP'; }
      else if (side === 'BUY' && c.open >= takeProfit) { exitPrice = c.open; exitReason = 'TARGET_GAP'; }
      else if (side === 'SELL' && c.open >= stopLoss) { exitPrice = c.open; exitReason = 'STOP_GAP'; }
      else if (side === 'SELL' && c.open <= takeProfit) { exitPrice = c.open; exitReason = 'TARGET_GAP'; }
      else {
        const stopHit = side === 'BUY' ? c.low <= stopLoss : c.high >= stopLoss;
        const targetHit = side === 'BUY' ? c.high >= takeProfit : c.low <= takeProfit;
        // OHLC cannot reveal intrabar ordering. Conservative convention: stop wins if both are touched.
        if (stopHit) { exitPrice = stopLoss; exitReason = targetHit ? 'STOP_AND_TARGET_SAME_BAR_STOP_FIRST' : 'STOP'; }
        else if (targetHit) { exitPrice = takeProfit; exitReason = 'TARGET'; }
        else if (i === lastIndex && i === startIndex + maxHoldingBars - 1) { exitPrice = c.close; exitReason = 'TIME_EXIT'; }
      }
      if (exitPrice !== null) {
        const grossMove = sign * (exitPrice - entryPrice);
        const netMove = grossMove - totalRoundTripCostPrice;
        const elapsedToExitBarOpen = (c.timestamp - candles[startIndex].timestamp) / 60000;
        const exitTimingPrecision = exitReason === 'STOP_GAP' || exitReason === 'TARGET_GAP' ? 'BAR_OPEN' : exitReason === 'TIME_EXIT' ? 'BAR_CLOSE_MODELLED' : 'INTRABAR_UNKNOWN';
        const elapsedExposureLowerBoundMinutes = elapsedToExitBarOpen + (exitTimingPrecision === 'BAR_CLOSE_MODELLED' ? 15 : 0);
        const elapsedExposureUpperBoundMinutes = elapsedToExitBarOpen + (exitTimingPrecision === 'INTRABAR_UNKNOWN' || exitTimingPrecision === 'BAR_CLOSE_MODELLED' ? 15 : 0);
        return { status: 'CLOSED', side, entryPrice, stopLoss, takeProfit, exitPrice, exitReason, exitIndex: i, entryIndex: startIndex, barsHeld: i - startIndex + 1, elapsedExposureLowerBoundMinutes, elapsedExposureUpperBoundMinutes, exitTimingPrecision, grossR: grossMove / stopDistance, netR: netMove / stopDistance, costR: totalRoundTripCostPrice / stopDistance, roundTripCostPrice: totalRoundTripCostPrice, costBreakdown };
      }
    }
    const elapsedToLastBarOpen = (candles[lastIndex].timestamp - candles[startIndex].timestamp) / 60000;
    return { status: 'OPEN_AT_DATA_END', side, entryPrice, stopLoss, takeProfit, entryIndex: startIndex, lastObservedIndex: lastIndex, barsHeld: lastIndex - startIndex + 1, elapsedExposureLowerBoundMinutes: elapsedToLastBarOpen, elapsedExposureUpperBoundMinutes: elapsedToLastBarOpen + 15, exitTimingPrecision: 'UNRESOLVED_WITHIN_LAST_OBSERVED_BAR' };
  }

  function measureM15Coverage(candles, startIndex = 0, endIndex = null) {
    if (!Array.isArray(candles) || candles.length === 0) return { observedCandles: 0, gapCount: 0, missingIntervalSlots: 0, maxGapMinutes: 0, elapsedWindowMinutes: 0, gridSlots: 0, timestampGridCoveragePercent: null, interpretation: 'No candle timestamps available.' };
    const start = Math.max(0, startIndex);
    const end = Math.min(candles.length - 1, endIndex == null ? candles.length - 1 : endIndex);
    if (!Number.isInteger(start) || !Number.isInteger(end) || end < start || !Number.isFinite(candles[start]?.timestamp) || !Number.isFinite(candles[end]?.timestamp)) {
      return { observedCandles: 0, gapCount: 0, missingIntervalSlots: 0, maxGapMinutes: 0, elapsedWindowMinutes: 0, gridSlots: 0, timestampGridCoveragePercent: null, interpretation: 'Invalid candle range or timestamps.' };
    }
    const selected = candles.slice(start, end + 1);
    const intervalMs = 15 * 60 * 1000;
    let gapCount = 0, missingIntervalSlots = 0, maxGapMinutes = 0;
    for (let i = 1; i < selected.length; i++) {
      const delta = selected[i].timestamp - selected[i - 1].timestamp;
      if (!Number.isFinite(delta) || delta <= 0 || delta % intervalMs !== 0) {
        return { observedCandles: selected.length, gapCount, missingIntervalSlots, maxGapMinutes, elapsedWindowMinutes: null, gridSlots: null, timestampGridCoveragePercent: null, interpretation: 'Timestamp spacing is invalid for a 15-minute grid.' };
      }
      if (delta > intervalMs) {
        gapCount++;
        missingIntervalSlots += delta / intervalMs - 1;
        maxGapMinutes = Math.max(maxGapMinutes, delta / 60000);
      }
    }
    const elapsedWindowMinutes = (selected[selected.length - 1].timestamp + intervalMs - selected[0].timestamp) / 60000;
    const gridSlots = Math.round(elapsedWindowMinutes / 15);
    return {
      observedCandles: selected.length, gapCount, missingIntervalSlots, maxGapMinutes,
      elapsedWindowMinutes, gridSlots,
      timestampGridCoveragePercent: gridSlots > 0 ? selected.length / gridSlots * 100 : null,
      interpretation: 'Timestamp-grid coverage only: gaps may represent market closures or missing provider rows; this is not market-open coverage.'
    };
  }

  function summarize(trades) {
    const wins = trades.filter(t => t.netR > 1e-10), losses = trades.filter(t => t.netR < -1e-10), flat = trades.length - wins.length - losses.length;
    const netRs = trades.map(t => t.netR);
    const grossProfitR = wins.reduce((s, t) => s + t.netR, 0);
    const grossLossR = -losses.reduce((s, t) => s + t.netR, 0);
    let equity = 0, peak = 0, maxDrawdownR = 0;
    for (const t of trades) { equity += t.netR; peak = Math.max(peak, equity); maxDrawdownR = Math.max(maxDrawdownR, peak - equity); }
    return {
      closedTrades: trades.length, wins: wins.length, losses: losses.length, breakeven: flat,
      winRatePercent: trades.length ? wins.length / trades.length * 100 : null,
      netR: netRs.reduce((s, x) => s + x, 0), grossProfitR, grossLossR,
      profitFactor: grossLossR > 0 ? grossProfitR / grossLossR : (grossProfitR > 0 ? Infinity : null),
      expectancyR: trades.length ? netRs.reduce((s, x) => s + x, 0) / trades.length : null,
      maxDrawdownR
    };
  }

  function run({ h1, m15, settings = {} }) {
    const errors = [];
    if (!h1?.validation?.valid || !m15?.validation?.valid) errors.push('Both H1 and M15 datasets must pass candle validation.');
    if (!Array.isArray(h1?.candles) || h1.candles.length < 210) errors.push('Backtest requires at least 210 H1 candles.');
    if (!Array.isArray(m15?.candles) || m15.candles.length < 40) errors.push('Backtest requires at least 40 M15 candles.');
    if (Array.isArray(h1?.candles)) errors.push(...validateOHLCSeries(h1.candles, 'H1'));
    if (Array.isArray(m15?.candles)) errors.push(...validateOHLCSeries(m15.candles, 'M15'));
    if (Array.isArray(h1?.candles) && Array.isArray(m15?.candles) && h1.candles.length && m15.candles.length && h1.candles[h1.candles.length - 1].timestamp > m15.candles[m15.candles.length - 1].timestamp) errors.push('H1 dataset ends after M15 dataset; timeframe snapshots are not aligned.');
    if (root.XAUUSD.DataIntegrity?.validateTimeframeAlignment && Array.isArray(h1?.candles) && Array.isArray(m15?.candles)) errors.push(...root.XAUUSD.DataIntegrity.validateTimeframeAlignment(h1.candles, m15.candles));
    const maxHoldingBars = Number(settings.maxHoldingBars ?? 96);
    const roundTripCostPrice = Number(settings.roundTripCostPrice ?? 0);
    const spreadCostPrice = Number(settings.spreadCostPrice ?? 0);
    const commissionCostPrice = Number(settings.commissionCostPrice ?? 0);
    const slippageCostPrice = Number(settings.slippageCostPrice ?? 0);
    const atrMultiplier = Number(settings.atrMultiplier ?? 1.5);
    const rewardRisk = Number(settings.rewardRisk ?? 2);
    const signalStartTime = settings.signalStartTime == null ? null : Number(settings.signalStartTime);
    if (!Number.isInteger(maxHoldingBars) || maxHoldingBars < 1 || maxHoldingBars > 1000) errors.push('Maximum holding bars must be an integer from 1 to 1000.');
    if (![roundTripCostPrice, spreadCostPrice, commissionCostPrice, slippageCostPrice].every(x => Number.isFinite(x) && x >= 0)) errors.push('All round-trip cost components must be finite non-negative XAU price amounts.');
    if (!Number.isFinite(atrMultiplier) || atrMultiplier <= 0 || atrMultiplier > 5) errors.push('ATR multiplier must be greater than 0 and no more than 5.');
    if (!Number.isFinite(rewardRisk) || rewardRisk < 1 || rewardRisk > 5) errors.push('Reward/risk must be between 1:1 and 5:1.');
    if (signalStartTime !== null && !Number.isFinite(signalStartTime)) errors.push('Signal start time must be a valid Unix-millisecond timestamp.');
    if (errors.length) return { valid: false, errors, trades: [], summary: summarize([]) };

    const trades = [], unresolvedTrades = []; let signalCount = 0, unresolvedSignals = 0, skippedGapEntries = 0;
    const h1Candles = h1.candles, m15Candles = m15.candles;
    let nextH1Index = 0, latestCompletedH1 = [];
    for (let i = 30; i < m15Candles.length - 1; i++) {
      const signalBar = m15Candles[i];
      if (signalStartTime !== null && signalBar.timestamp < signalStartTime) continue;
      const signalCloseTime = signalBar.timestamp + 15 * 60 * 1000;
      while (nextH1Index < h1Candles.length && h1Candles[nextH1Index].timestamp + 60 * 60 * 1000 <= signalCloseTime) {
        latestCompletedH1.push(h1Candles[nextH1Index]); nextH1Index++;
      }
      if (latestCompletedH1.length < 210) continue;
      const market = root.XAUUSD.MarketAnalyst.analyzeH1(latestCompletedH1);
      const signal = root.XAUUSD.SignalAnalyst.analyzeM15(m15Candles.slice(0, i + 1), market);
      if (signal.candidate === 'WAIT') continue;
      signalCount++;
      // A next observed row is not necessarily the immediately following M15 bar.
      // Do not carry a just-closed signal across a missing interval/session gap.
      if (m15Candles[i + 1].timestamp !== signalBar.timestamp + 15 * 60 * 1000) {
        skippedGapEntries++;
        continue;
      }
      const risk = root.XAUUSD.RiskAnalyst.assess(signal, { atrMultiplier, rewardRisk, maxRiskPercent: 0.5 });
      const dataset = { valid: true };
      const review = root.XAUUSD.QualityReviewer.review(dataset, market, signal, risk);
      if (!risk.valid || !review.approved) continue;
      const trade = simulateTrade({ side: signal.candidate, entryPrice: m15Candles[i + 1].open, stopDistance: risk.stopDistance, rewardRisk, candles: m15Candles, startIndex: i + 1, maxHoldingBars, roundTripCostPrice, spreadCostPrice, commissionCostPrice, slippageCostPrice });
      if (trade.status === 'CLOSED') {
        trade.signalTime = signalBar.time; trade.entryTime = m15Candles[trade.entryIndex].time; trade.exitTime = m15Candles[trade.exitIndex].time;
        trades.push(trade); i = trade.exitIndex;
      } else if (trade.status === 'OPEN_AT_DATA_END') {
        // The simulator has consumed every remaining candle. Keep the position unresolved
        // and stop evaluating later signals so the one-position-at-a-time model is preserved.
        unresolvedSignals++;
        unresolvedTrades.push({
          status: 'UNRESOLVED', side: trade.side, entryPrice: trade.entryPrice,
          stopLoss: trade.stopLoss, takeProfit: trade.takeProfit,
          entryIndex: trade.entryIndex, lastObservedIndex: trade.lastObservedIndex,
          barsHeld: trade.barsHeld, elapsedExposureLowerBoundMinutes: trade.elapsedExposureLowerBoundMinutes, elapsedExposureUpperBoundMinutes: trade.elapsedExposureUpperBoundMinutes, exitTimingPrecision: trade.exitTimingPrecision, entryTime: m15Candles[trade.entryIndex].time,
          lastObservedTime: m15Candles[trade.lastObservedIndex].time,
          lastObservedClose: m15Candles[trade.lastObservedIndex].close
        });
        break;
      }
    }
    return {
      valid: true, dataCoverage: measureM15Coverage(m15Candles), method: 'bar-close signal; immediately-following-M15-open entry; gap candidates skipped; completed-H1-only context; conservative stop-first intrabar tie-break',
      assumptions: [
        'Signals are evaluated only after each M15 candle closes; entry is at the immediately following M15 open. If that candle does not open exactly 15 minutes after the signal candle, the candidate is skipped rather than carried across a data/session gap.',
        'Only H1 candles whose full 60-minute interval ended by the signal time are visible (prevents H1 look-ahead).',
        'If stop and target are both touched in one OHLC bar, stop is assumed first.',
        'Spread, commission and slippage are separately user-supplied round-trip XAU price amounts; legacy aggregate cost is additive. Zero means the component is excluded, not zero in reality.',
        'Maximum holding bars counts observed M15 candles, not elapsed wall-clock time. Elapsed exposure is reported as a lower/upper bound: gap exits at bar open and modelled time exits at bar close have a single modelled duration; intrabar stop/target exits have a 15-minute uncertainty window; unresolved positions span the last observed candle open-to-close. Timestamp differences may use broker-server wall-clock ordering, not verified UTC. These diagnostics do not change holding or exit rules. An unresolved position is excluded from closed-trade statistics and blocks later entries.',
        'Cost components are not converted from broker points, lots or account currency; no swaps, partial fills, dynamic spread or intrabar tick simulation is performed.'
      ],
      parameters: { atrMultiplier, rewardRisk, maxHoldingBars, roundTripCostPrice, spreadCostPrice, commissionCostPrice, slippageCostPrice, totalRoundTripCostPrice: roundTripCostPrice + spreadCostPrice + commissionCostPrice + slippageCostPrice, signalStartTime },
      evaluationStartTime: signalStartTime,
      signals: signalCount, skippedGapEntries, unresolvedSignals, unresolvedTrades, trades, summary: summarize(trades)
    };
  }

  function runOutOfSample({ h1, m15, settings = {}, trainFraction = 0.7 }) {
    if (!Number.isFinite(trainFraction) || trainFraction < 0.5 || trainFraction > 0.9) {
      return { valid: false, errors: ['Training fraction must be between 0.50 and 0.90.'], result: null };
    }
    if (!Array.isArray(m15?.candles) || m15.candles.length < 80) {
      return { valid: false, errors: ['Out-of-sample evaluation requires at least 80 M15 candles.'], result: null };
    }
    const splitIndex = Math.floor(m15.candles.length * trainFraction);
    const testBars = m15.candles.length - splitIndex;
    if (splitIndex < 40 || testBars < 40) {
      return { valid: false, errors: ['The chronological split must leave at least 40 M15 candles in both warm-up/training and test periods.'], result: null };
    }
    const splitCandle = m15.candles[splitIndex];
    const result = run({ h1, m15, settings: { ...settings, signalStartTime: splitCandle.timestamp } });
    if (!result.valid) return { valid: false, errors: result.errors, result: null };
    return {
      valid: true, testCoverage: measureM15Coverage(m15.candles, splitIndex, m15.candles.length - 1), method: 'single chronological holdout; all pre-split candles used only for indicator/H1 warm-up; no parameter fitting; unresolved end-boundary trades separately reported and excluded from closed-trade metrics',
      trainFraction, splitIndex, trainingBars: splitIndex, testBars, testStartIndex: splitIndex, testEndIndex: m15.candles.length - 1, testStartTime: splitCandle.time, testEndTime: m15.candles[m15.candles.length - 1].time,
      boundaryPolicy: 'Test window is the final contiguous row segment [splitIndex, lastIndex]. Signals before split are excluded. Entries require the immediately following M15 open. A position not closed by the final available test candle is counted unresolved, excluded from closed-trade metrics, and blocks subsequent entries. Unresolved position details are reported separately and are not counted as closed trades; no candles beyond the test window are supplied to simulation.',
      result, warning: 'Use this holdout once. If you change rules or parameters after inspecting these results, this period is no longer an untouched out-of-sample test.'
    };
  }

  root.XAUUSD = root.XAUUSD || {};
  root.XAUUSD.Backtester = { run, runOutOfSample, simulateTrade, summarize, validateOHLCSeries, measureM15Coverage };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.XAUUSD.Backtester;
})(globalThis);
