(function (root) {
  function analyzeM15(candles, market) {
    const I = root.XAUUSD.Indicators;
    const closes = candles.map(c => c.close);
    const e20 = I.ema(closes, 20), r = I.rsi(closes, 14), a = I.atr(candles, 14);
    const i = candles.length - 1, last = candles[i], prev = candles[i - 1];
    let candidate = 'WAIT'; let reasons = ['Entry conditions are not fully aligned.'];
    if (market.trend === 'BULLISH' && last.close > e20[i] && r[i] >= 50 && r[i] <= 70 && last.close > prev.high) {
      candidate = 'BUY'; reasons = ['H1 trend is bullish.', 'M15 close is above EMA20.', 'RSI is between 50 and 70.', 'M15 close is above the previous candle high.'];
    } else if (market.trend === 'BEARISH' && last.close < e20[i] && r[i] >= 30 && r[i] <= 50 && last.close < prev.low) {
      candidate = 'SELL'; reasons = ['H1 trend is bearish.', 'M15 close is below EMA20.', 'RSI is between 30 and 50.', 'M15 close is below the previous candle low.'];
    }
    return { agent: 'Signal Analyst', timeframe: 'M15', candidate, close: last.close, ema20: e20[i], rsi14: r[i], atr14: a[i], previousHigh: prev.high, previousLow: prev.low, candleTime: last.time, reasons };
  }
  root.XAUUSD = root.XAUUSD || {};
  root.XAUUSD.SignalAnalyst = { analyzeM15 };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.XAUUSD.SignalAnalyst;
})(globalThis);
