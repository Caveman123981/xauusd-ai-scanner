(function (root) {
  function assess(signal, settings = {}) {
    const atrMultiplier = Number(settings.atrMultiplier ?? 1.5);
    const rewardRisk = Number(settings.rewardRisk ?? 2);
    const maxRiskPercent = Number(settings.maxRiskPercent ?? 0.5);
    const errors = [];
    if (!(atrMultiplier > 0 && atrMultiplier <= 5)) errors.push('ATR stop multiplier must be greater than 0 and no more than 5.');
    if (!(rewardRisk >= 1 && rewardRisk <= 5)) errors.push('Reward/risk must be between 1:1 and 5:1.');
    if (!(maxRiskPercent > 0 && maxRiskPercent <= 1)) errors.push('Configured risk must be greater than 0% and no more than 1%.');
    if (!Number.isFinite(signal.atr14) || signal.atr14 <= 0) errors.push('A valid positive M15 ATR is required.');
    if (!Number.isFinite(signal.close) || signal.close <= 0) errors.push('A valid reference price is required.');
    if (errors.length || signal.candidate === 'WAIT') return { agent: 'Risk Analyst', valid: errors.length === 0, errors, stopLoss: null, takeProfit: null, stopDistance: null, rewardRisk, maxRiskPercent };
    const stopDistance = signal.atr14 * atrMultiplier;
    const buy = signal.candidate === 'BUY';
    const stopLoss = buy ? signal.close - stopDistance : signal.close + stopDistance;
    const takeProfit = buy ? signal.close + stopDistance * rewardRisk : signal.close - stopDistance * rewardRisk;
    if (stopLoss <= 0 || takeProfit <= 0) errors.push('Calculated stop or target is not a positive price.');
    return { agent: 'Risk Analyst', valid: errors.length === 0, errors, stopLoss, takeProfit, stopDistance, rewardRisk, maxRiskPercent, atrMultiplier };
  }
  function calculatePositionSize({ balance, riskPercent, stopDistance, usdPerOneDollarMovePerLot, minLot = 0.01, lotStep = 0.01, maxLot = 100 }) {
    const v = [balance, riskPercent, stopDistance, usdPerOneDollarMovePerLot, minLot, lotStep, maxLot].map(Number);
    if (!v.every(Number.isFinite) || balance <= 0 || riskPercent <= 0 || riskPercent > 1 || stopDistance <= 0 || usdPerOneDollarMovePerLot <= 0 || minLot <= 0 || lotStep <= 0 || maxLot < minLot) {
      return { valid: false, error: 'Enter valid broker specifications and risk no greater than 1%.' };
    }
    const riskCash = balance * riskPercent / 100;
    const rawLots = riskCash / (stopDistance * usdPerOneDollarMovePerLot);
    const lots = Math.floor((rawLots + 1e-10) / lotStep) * lotStep;
    if (lots < minLot) return { valid: false, error: 'Calculated size is below the broker minimum lot; reduce risk or do not take the trade.', rawLots, riskCash };
    if (lots > maxLot) return { valid: false, error: 'Calculated size exceeds the configured maximum lot; verify broker specifications.', rawLots, riskCash };
    return { valid: true, lots: Number(lots.toFixed(8)), rawLots, riskCash, estimatedRisk: lots * stopDistance * usdPerOneDollarMovePerLot };
  }
  root.XAUUSD = root.XAUUSD || {};
  root.XAUUSD.RiskAnalyst = { assess, calculatePositionSize };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.XAUUSD.RiskAnalyst;
})(globalThis);
