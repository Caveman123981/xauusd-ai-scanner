(function (root) {
  const INTERVAL_SECONDS = { H1: 3600, M15: 900 };
  function classifyTimestamp(value) {
    const s = String(value ?? '').trim();
    if (/^\d{10}$/.test(s) || /^\d{13}$/.test(s)) return 'absolute_epoch';
    // MetaTrader exports commonly contain broker-server wall-clock time without an offset.
    // Encode the wall clock as a pseudo-UTC number for ordering only; it is NOT UTC.
    const broker = s.match(/^(\d{4})\.(\d{2})\.(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/);
    if (broker) return 'broker_server_wall_clock';
    // ISO timestamps must carry Z or an explicit numeric offset. Naive ISO/local times
    // depend on the device timezone and are therefore rejected.
    if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:Z|[+-]\d{2}:\d{2})$/i.test(s)) return 'absolute_iso';
    return 'unsupported';
  }
  function parseTimestamp(value) {
    const s = String(value ?? '').trim();
    if (!s) return NaN;
    if (/^\d{10}$/.test(s)) return Number(s) * 1000;
    if (/^\d{13}$/.test(s)) return Number(s);
    const mt = s.match(/^(\d{4})\.(\d{2})\.(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/);
    if (mt) {
      const parts = [+mt[1], +mt[2], +mt[3], +mt[4], +mt[5], +(mt[6] || 0)];
      const value = Date.UTC(parts[0], parts[1] - 1, parts[2], parts[3], parts[4], parts[5]);
      const d = new Date(value);
      if (d.getUTCFullYear() !== parts[0] || d.getUTCMonth() + 1 !== parts[1] || d.getUTCDate() !== parts[2] || d.getUTCHours() !== parts[3] || d.getUTCMinutes() !== parts[4] || d.getUTCSeconds() !== parts[5]) return NaN;
      return value;
    }
    if (classifyTimestamp(s) !== 'absolute_iso') return NaN;
    const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,9}))?(Z|([+-])(\d{2}):(\d{2}))$/i);
    if (!iso) return NaN;
    const parts = [+iso[1], +iso[2], +iso[3], +iso[4], +iso[5], +iso[6]];
    const calendar = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2], parts[3], parts[4], parts[5]));
    if (calendar.getUTCFullYear() !== parts[0] || calendar.getUTCMonth() + 1 !== parts[1] || calendar.getUTCDate() !== parts[2] || calendar.getUTCHours() !== parts[3] || calendar.getUTCMinutes() !== parts[4] || calendar.getUTCSeconds() !== parts[5]) return NaN;
    if (iso[10] !== undefined && (+iso[10] > 23 || +iso[11] > 59)) return NaN;
    const parsed = Date.parse(s);
    return Number.isFinite(parsed) ? parsed : NaN;
  }
  function splitCSVLine(line) {
    const out = []; let value = ''; let quoted = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"' && quoted && line[i + 1] === '"') { value += '"'; i++; }
      else if (ch === '"') quoted = !quoted;
      else if (ch === ',' && !quoted) { out.push(value.trim()); value = ''; }
      else value += ch;
    }
    if (quoted) throw new Error('CSV contains an unterminated quoted field.');
    out.push(value.trim());
    return out;
  }
  function parseCSV(text, timeframe) {
    if (!INTERVAL_SECONDS[timeframe]) throw new Error('Timeframe must be H1 or M15.');
    const lines = String(text).replace(/^\uFEFF/, '').split(/\r?\n/).filter(x => x.trim());
    if (lines.length < 2) throw new Error('CSV must contain a header and candle rows.');
    const headers = splitCSVLine(lines[0]).map(x => x.toLowerCase());
    const indexes = {};
    indexes.time = headers.findIndex(x => ['time', 'timestamp', 'datetime', 'date'].includes(x));
    for (const key of ['open', 'high', 'low', 'close']) indexes[key] = headers.indexOf(key);
    const missing = Object.keys(indexes).filter(k => indexes[k] < 0);
    if (missing.length) throw new Error(`Missing required CSV column(s): ${missing.join(', ')}.`);
    const rows = [];
    const timestampBases = new Set();
    for (let lineNo = 1; lineNo < lines.length; lineNo++) {
      let cells;
      try { cells = splitCSVLine(lines[lineNo]); }
      catch (e) { throw new Error(`Line ${lineNo + 1}: ${e.message}`); }
      const time = cells[indexes.time];
      const timestamp = parseTimestamp(time);
      const timestampBasis = classifyTimestamp(time);
      timestampBases.add(timestampBasis);
      const candle = { time, timestamp, timestampBasis };
      for (const key of ['open', 'high', 'low', 'close']) candle[key] = Number(cells[indexes[key]]);
      const volumeIndex = headers.findIndex(x => ['tickvolume', 'tick_volume', 'volume'].includes(x));
      const spreadIndex = headers.findIndex(x => ['spread', 'spreadpoints', 'spread_points'].includes(x));
      if (volumeIndex >= 0 && cells[volumeIndex] !== '') { candle.tickVolume = Number(cells[volumeIndex]); if (!Number.isFinite(candle.tickVolume) || candle.tickVolume < 0) throw new Error(`Line ${lineNo + 1}: tick volume must be a finite non-negative number.`); }
      if (spreadIndex >= 0 && cells[spreadIndex] !== '') { candle.spreadPoints = Number(cells[spreadIndex]); if (!Number.isFinite(candle.spreadPoints) || candle.spreadPoints < 0) throw new Error(`Line ${lineNo + 1}: spread points must be a finite non-negative number.`); }
      if (!Number.isFinite(timestamp)) throw new Error(`Line ${lineNo + 1}: invalid or unsupported timestamp '${time}'. Timezone-naive ISO/local timestamps are not accepted; use Z or an explicit offset.`);
      if (!['open', 'high', 'low', 'close'].every(k => Number.isFinite(candle[k]) && candle[k] > 0)) {
        throw new Error(`Line ${lineNo + 1}: OHLC values must be finite positive numbers.`);
      }
      const bodyHigh = Math.max(candle.open, candle.close);
      const bodyLow = Math.min(candle.open, candle.close);
      if (candle.high < candle.low || candle.high < bodyHigh || candle.low > bodyLow) {
        throw new Error(`Line ${lineNo + 1}: inconsistent OHLC range.`);
      }
      rows.push(candle);
    }
    if (timestampBases.has('unsupported')) throw new Error('CSV contains a timezone-naive or unsupported timestamp. Use MetaTrader broker-clock format, Unix epoch, or ISO-8601 with Z/explicit offset.');
    if (timestampBases.has('broker_server_wall_clock') && timestampBases.size > 1) throw new Error('CSV mixes broker-server wall-clock timestamps with absolute epoch/offset timestamps. Normalize the source before import.');
    const timestampBasis = timestampBases.has('broker_server_wall_clock') ? 'broker_server_wall_clock' : 'absolute';
    const validation = validateCandles(rows, timeframe);
    if (!validation.valid) throw new Error(validation.errors.join(' '));
    return { candles: rows, validation, timestampBasis, timeBasis: timestampBasis === 'broker_server_wall_clock' ? 'Broker-server wall-clock; pseudo-UTC values are for ordering only and are not UTC instants.' : 'Absolute timestamps (Unix epoch or ISO-8601 with explicit timezone offset).'};
  }
  function validateCandles(candles, timeframe) {
    const errors = []; const warnings = [];
    const expected = INTERVAL_SECONDS[timeframe] * 1000;
    if (!Array.isArray(candles) || candles.length === 0) return { valid: false, errors: ['No candles supplied.'], warnings, gaps: 0 };
    let gaps = 0;
    for (let i = 1; i < candles.length; i++) {
      const delta = candles[i].timestamp - candles[i - 1].timestamp;
      if (delta === 0) errors.push(`Duplicate candle timestamp at row ${i + 1}.`);
      else if (delta < 0) errors.push(`Candles are not chronological at row ${i + 1}.`);
      else {
        if (delta % expected !== 0) errors.push(`Candle interval at row ${i + 1} is not an integer multiple of the ${timeframe} interval; irregular bar spacing is not supported.`);
        if (delta > expected) gaps++;
      }
    }
    if (gaps) warnings.push(`${gaps} time gap(s) detected. Market closures may explain some gaps; inspect missing data before relying on results.`);
    return { valid: errors.length === 0, errors, warnings, gaps, count: candles.length, firstTime: candles[0].time, lastTime: candles[candles.length - 1].time };
  }
  function validateTimeframeAlignment(h1Candles, m15Candles) {
    const errors = [];
    if (!Array.isArray(h1Candles) || !h1Candles.length || !Array.isArray(m15Candles) || !m15Candles.length) return errors;
    for (const [candles, timeframe] of [[h1Candles, 'H1'], [m15Candles, 'M15']]) {
      const expected = INTERVAL_SECONDS[timeframe] * 1000;
      for (let i = 1; i < candles.length; i++) {
        const delta = candles[i].timestamp - candles[i - 1].timestamp;
        if (Number.isFinite(delta) && delta > 0 && delta % expected !== 0) {
          errors.push(`${timeframe} candle ${i + 1} has irregular spacing; intervals must be integer multiples of the ${timeframe} duration.`);
          break;
        }
      }
    }
    const m15Anchor = m15Candles[0].timestamp;
    const m15Interval = INTERVAL_SECONDS.M15 * 1000;
    for (let i = 0; i < h1Candles.length; i++) {
      const offset = h1Candles[i].timestamp - m15Anchor;
      if (Number.isFinite(offset) && offset % m15Interval !== 0) {
        errors.push(`H1 candle ${i + 1} does not align to the M15 timeline; H1 opens must fall on an M15 interval boundary.`);
        break;
      }
    }
    return errors;
  }
  function validateDataset(h1, m15) {
    const errors = []; const warnings = [];
    if (h1.candles.length < 210) errors.push(`H1 needs at least 210 candles; received ${h1.candles.length}.`);
    if (m15.candles.length < 30) errors.push(`M15 needs at least 30 candles; received ${m15.candles.length}.`);
    if (h1.timestampBasis && m15.timestampBasis && h1.timestampBasis !== m15.timestampBasis) {
      errors.push('H1 and M15 timestamp bases differ. Both datasets must use broker-server wall-clock time or absolute timezone-aware timestamps.');
    }
    if (h1.candles.length && m15.candles.length && h1.candles.at(-1).timestamp > m15.candles.at(-1).timestamp) {
      errors.push('H1 data ends after M15 data. The timeframe snapshots are not aligned.');
    }
    errors.push(...validateTimeframeAlignment(h1.candles, m15.candles));
    warnings.push(...h1.validation.warnings.map(x => `H1: ${x}`), ...m15.validation.warnings.map(x => `M15: ${x}`));
    return { valid: errors.length === 0, errors, warnings };
  }
  root.XAUUSD = root.XAUUSD || {};
  root.XAUUSD.DataIntegrity = { parseTimestamp, classifyTimestamp, splitCSVLine, parseCSV, validateCandles, validateTimeframeAlignment, validateDataset, INTERVAL_SECONDS };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.XAUUSD.DataIntegrity;
})(globalThis);
