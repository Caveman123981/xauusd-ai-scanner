(function (root) {
  const BASE = 'https://www.algospecial.com/api/ohlc.php';
  const MAX_DAYS = 31;
  const MAX_ROWS = 2000;
  async function fetchCandles({ timeframe, from, to, fetchImpl = globalThis.fetch }) {
    if (!['H1', 'M15'].includes(timeframe)) throw new Error('Only H1 and M15 are supported by this scanner.');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) throw new Error('Choose valid start and end dates.');
    const start = Date.parse(`${from}T00:00:00Z`), end = Date.parse(`${to}T00:00:00Z`);
    if (!Number.isFinite(start) || !Number.isFinite(end) || end < start) throw new Error('The end date must be on or after the start date.');
    const days = Math.floor((end - start) / 86400000) + 1;
    if (days > MAX_DAYS) throw new Error(`Free preview is limited to ${MAX_DAYS} calendar days per request.`);
    if (typeof fetchImpl !== 'function') throw new Error('Fetch is unavailable in this browser.');
    const params = new URLSearchParams({ symbol: 'XAUUSD', tf: timeframe, from, to, format: 'csv' });
    const response = await fetchImpl(`${BASE}?${params.toString()}`, { method: 'GET', mode: 'cors', cache: 'no-store', headers: { Accept: 'text/csv' } });
    const body = await response.text();
    if (!response.ok) throw new Error(`Historical data provider returned HTTP ${response.status}${body ? `: ${body.slice(0, 180)}` : '.'}`);
    const parsed = root.XAUUSD.DataIntegrity.parseCSV(body, timeframe);
    if (parsed.candles.length > MAX_ROWS) throw new Error(`Provider returned ${parsed.candles.length} rows; free preview cap is ${MAX_ROWS}. Narrow the date range.`);
    return {
      ...parsed,
      source: 'AlgoSpecial free historical preview',
      symbol: 'XAUUSD',
      timeframe,
      requestedFrom: from,
      requestedTo: to,
      timeBasis: 'Provider broker-server clock; preserved as supplied and not converted to UTC.',
      historicalOnly: true,
      warnings: [
        ...parsed.validation.warnings,
        'Historical preview only; not a live quote or current trading feed.',
        'Provider timestamps use broker server time; do not apply session filters until the timezone is confirmed.',
        'Compare prices, spread and contract specifications with your own broker before any trading use.'
      ]
    };
  }
  root.XAUUSD = root.XAUUSD || {};
  root.XAUUSD.AlgoSpecialProvider = { fetchCandles, MAX_DAYS, MAX_ROWS, BASE };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.XAUUSD.AlgoSpecialProvider;
})(globalThis);
