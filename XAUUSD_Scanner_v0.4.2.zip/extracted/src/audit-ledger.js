(function (root) {
  const LEDGER_VERSION = '1.2';
  const HEADERS = [
    'record_type', 'ledger_version', 'scanner_release', 'symbol', 'strategy_id', 'trade_id',
    'signal_time', 'entry_time', 'exit_time', 'side', 'entry_price', 'stop_loss',
    'take_profit', 'exit_price', 'exit_reason', 'entry_index', 'exit_index',
    'bars_held', 'gross_r', 'net_r', 'cost_r', 'round_trip_cost_price',
    'legacy_aggregate_cost_price', 'spread_cost_price', 'commission_cost_price',
    'slippage_cost_price', 'last_observed_time', 'last_observed_index', 'last_observed_close', 'elapsed_exposure_lower_bound_minutes', 'elapsed_exposure_upper_bound_minutes', 'exit_timing_precision', 'unresolved_position_count', 'atr_multiplier', 'reward_risk', 'max_holding_bars', 'signal_start_time',
    'h1_candle_count', 'h1_first_time', 'h1_last_time', 'h1_timestamp_basis', 'm15_candle_count',
    'm15_first_time', 'm15_last_time', 'm15_timestamp_basis', 'backtest_method'
  ];

  function csvCell(value) {
    if (value === null || value === undefined || (typeof value === 'number' && !Number.isFinite(value))) return '';
    let text = String(value);
    if (typeof value === 'string' && /^[\t\r ]*[=+\-@]/.test(text)) text = `'${text}`;
    return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  }

  function candleTime(candle) {
    if (typeof candle?.time === 'string' && candle.time) return candle.time;
    return Number.isFinite(candle?.timestamp) ? new Date(candle.timestamp).toISOString() : '';
  }

  function datasetRange(dataset) {
    const candles = dataset?.candles || [];
    return {
      count: candles.length,
      first: candles.length ? candleTime(candles[0]) : '',
      last: candles.length ? candleTime(candles[candles.length - 1]) : ''
    };
  }

  function createCSV({ result, h1, m15, scannerRelease = '0.4.2', strategyId = 'xau-h1-trend-m15-entry-v1' }) {
    if (!result?.valid || !Array.isArray(result.trades) || !result.parameters || typeof result.method !== 'string') {
      throw new Error('A valid completed backtest result is required to create an audit ledger.');
    }
    if (!Array.isArray(h1?.candles) || !Array.isArray(m15?.candles)) {
      throw new Error('Both H1 and M15 candle datasets are required for audit metadata.');
    }
    const h1Range = datasetRange(h1), m15Range = datasetRange(m15);
    const p = result.parameters;
    const rows = [HEADERS];
    const unresolvedTrades = Array.isArray(result.unresolvedTrades) ? result.unresolvedTrades : [];
    const metadata = { record_type: 'RUN_METADATA', unresolved_position_count: unresolvedTrades.length, ledger_version: LEDGER_VERSION, scanner_release: scannerRelease, symbol: 'XAUUSD', strategy_id: strategyId, round_trip_cost_price: p.totalRoundTripCostPrice, legacy_aggregate_cost_price: p.roundTripCostPrice, spread_cost_price: p.spreadCostPrice, commission_cost_price: p.commissionCostPrice, slippage_cost_price: p.slippageCostPrice, atr_multiplier: p.atrMultiplier, reward_risk: p.rewardRisk, max_holding_bars: p.maxHoldingBars, signal_start_time: p.signalStartTime == null ? '' : new Date(p.signalStartTime).toISOString(), h1_candle_count: h1Range.count, h1_first_time: h1Range.first, h1_last_time: h1Range.last, h1_timestamp_basis: h1.timestampBasis || 'unspecified', m15_candle_count: m15Range.count, m15_first_time: m15Range.first, m15_last_time: m15Range.last, m15_timestamp_basis: m15.timestampBasis || 'unspecified', backtest_method: result.method };
    rows.push(HEADERS.map(key => metadata[key]));
    result.trades.forEach((trade, index) => {
      const requiredNumbers = ['entryPrice', 'stopLoss', 'takeProfit', 'exitPrice', 'grossR', 'netR', 'costR', 'roundTripCostPrice'];
      if (!trade || trade.status !== 'CLOSED' || !['BUY', 'SELL'].includes(trade.side) || !Number.isInteger(trade.entryIndex) || !Number.isInteger(trade.exitIndex) || requiredNumbers.some(key => !Number.isFinite(trade[key]))) {
        throw new Error(`Trade ${index + 1} is not a complete, valid closed BUY/SELL record.`);
      }
      const entryTime = trade.entryTime || (Number.isInteger(trade.entryIndex) ? candleTime(m15.candles[trade.entryIndex]) : '');
      const exitTime = trade.exitTime || (Number.isInteger(trade.exitIndex) ? candleTime(m15.candles[trade.exitIndex]) : '');
      const signalTime = trade.signalTime || '';
      const timestampKey = Number.isInteger(trade.entryIndex) && Number.isFinite(m15.candles[trade.entryIndex]?.timestamp)
        ? m15.candles[trade.entryIndex].timestamp : entryTime || `row-${index + 1}`;
      const costs = trade.costBreakdown || {};
      const record = {
        record_type: 'TRADE', ledger_version: LEDGER_VERSION, scanner_release: scannerRelease, symbol: 'XAUUSD', strategy_id: strategyId,
        trade_id: `XAU-${timestampKey}-${String(index + 1).padStart(4, '0')}`,
        signal_time: signalTime, entry_time: entryTime, exit_time: exitTime, side: trade.side,
        entry_price: trade.entryPrice, stop_loss: trade.stopLoss, take_profit: trade.takeProfit,
        exit_price: trade.exitPrice, exit_reason: trade.exitReason, entry_index: trade.entryIndex,
        exit_index: trade.exitIndex, bars_held: trade.barsHeld, elapsed_exposure_lower_bound_minutes: trade.elapsedExposureLowerBoundMinutes, elapsed_exposure_upper_bound_minutes: trade.elapsedExposureUpperBoundMinutes, exit_timing_precision: trade.exitTimingPrecision, gross_r: trade.grossR, net_r: trade.netR,
        cost_r: trade.costR, round_trip_cost_price: trade.roundTripCostPrice,
        legacy_aggregate_cost_price: costs.legacyAggregate ?? 0, spread_cost_price: costs.spread ?? 0,
        commission_cost_price: costs.commission ?? 0, slippage_cost_price: costs.slippage ?? 0,
        atr_multiplier: p.atrMultiplier, reward_risk: p.rewardRisk, max_holding_bars: p.maxHoldingBars,
        h1_candle_count: h1Range.count, h1_first_time: h1Range.first, h1_last_time: h1Range.last, h1_timestamp_basis: h1.timestampBasis || 'unspecified',
        m15_candle_count: m15Range.count, m15_first_time: m15Range.first, m15_last_time: m15Range.last, m15_timestamp_basis: m15.timestampBasis || 'unspecified',
        backtest_method: result.method
      };
      rows.push(HEADERS.map(key => record[key]));
    });
    unresolvedTrades.forEach((trade, index) => {
      if (!trade || trade.status !== 'UNRESOLVED' || !['BUY', 'SELL'].includes(trade.side) || !Number.isInteger(trade.entryIndex) || !Number.isInteger(trade.lastObservedIndex) || !Number.isFinite(trade.entryPrice) || !Number.isFinite(trade.stopLoss) || !Number.isFinite(trade.takeProfit) || !Number.isInteger(trade.barsHeld)) {
        throw new Error(`Unresolved position ${index + 1} is not a valid unresolved-position record.`);
      }
      const record = {
        record_type: 'UNRESOLVED_POSITION', ledger_version: LEDGER_VERSION, scanner_release: scannerRelease,
        symbol: 'XAUUSD', strategy_id: strategyId,
        trade_id: `XAU-UNRESOLVED-${Number.isFinite(m15.candles[trade.entryIndex]?.timestamp) ? m15.candles[trade.entryIndex].timestamp : trade.entryIndex}-${String(index + 1).padStart(4, '0')}`,
        entry_time: trade.entryTime || candleTime(m15.candles[trade.entryIndex]), side: trade.side,
        entry_price: trade.entryPrice, stop_loss: trade.stopLoss, take_profit: trade.takeProfit,
        entry_index: trade.entryIndex, bars_held: trade.barsHeld, elapsed_exposure_lower_bound_minutes: trade.elapsedExposureLowerBoundMinutes, elapsed_exposure_upper_bound_minutes: trade.elapsedExposureUpperBoundMinutes, exit_timing_precision: trade.exitTimingPrecision,
        last_observed_time: trade.lastObservedTime || candleTime(m15.candles[trade.lastObservedIndex]),
        last_observed_index: trade.lastObservedIndex, last_observed_close: trade.lastObservedClose,
        atr_multiplier: p.atrMultiplier, reward_risk: p.rewardRisk, max_holding_bars: p.maxHoldingBars,
        h1_candle_count: h1Range.count, h1_first_time: h1Range.first, h1_last_time: h1Range.last,
        h1_timestamp_basis: h1.timestampBasis || 'unspecified', m15_candle_count: m15Range.count,
        m15_first_time: m15Range.first, m15_last_time: m15Range.last,
        m15_timestamp_basis: m15.timestampBasis || 'unspecified', backtest_method: result.method
      };
      rows.push(HEADERS.map(key => record[key]));
    });
    return rows.map(row => row.map(csvCell).join(',')).join('\r\n') + '\r\n';
  }

  root.XAUUSD = root.XAUUSD || {};
  root.XAUUSD.AuditLedger = { createCSV, csvCell, HEADERS, LEDGER_VERSION };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.XAUUSD.AuditLedger;
})(typeof globalThis !== 'undefined' ? globalThis : this);
