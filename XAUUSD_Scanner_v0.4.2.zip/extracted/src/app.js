(function () {
  const $ = id => document.getElementById(id);
  const state = { h1: null, m15: null, lastBacktest: null };
  function setStatus(id, message, kind = '') { $(id).textContent = message; $(id).className = `status ${kind}`.trim(); }
  function readFile(inputId, key, statusId, timeframe) {
    state.lastBacktest = null; $('exportAudit').disabled = true;
    const file = $(inputId).files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        state[key] = XAUUSD.DataIntegrity.parseCSV(String(reader.result), timeframe);
        const v = state[key].validation;
        setStatus(statusId, `Loaded ${v.count} candles · ${file.name} · ${state[key].timestampBasis === 'broker_server_wall_clock' ? 'broker clock (not UTC)' : 'absolute timestamps'}${v.gaps ? ` · ${v.gaps} gap(s)` : ''}`, v.gaps ? 'warn' : 'good');
      } catch (e) { state[key] = null; setStatus(statusId, e.message, 'bad'); }
    };
    reader.onerror = () => setStatus(statusId, 'Could not read the selected file.', 'bad');
    reader.readAsText(file);
  }
  $('fetchData').addEventListener('click', async () => {
    const button = $('fetchData');
    const from = $('apiFrom').value, to = $('apiTo').value;
    button.disabled = true; button.textContent = 'Fetching historical candles…';
    setStatus('apiStatus', 'Requesting H1 and M15 candles from the free historical preview…');
    try {
      const [h1, m15] = await Promise.all([
        XAUUSD.AlgoSpecialProvider.fetchCandles({ timeframe: 'H1', from, to }),
        XAUUSD.AlgoSpecialProvider.fetchCandles({ timeframe: 'M15', from, to })
      ]);
      state.h1 = h1; state.m15 = m15; state.lastBacktest = null; $('exportAudit').disabled = true;
      setStatus('h1status', `Historical API: ${h1.candles.length} H1 candles loaded · broker clock (not UTC) · ${h1.candles.at(-1).time}`, 'good');
      setStatus('m15status', `Historical API: ${m15.candles.length} M15 candles loaded · broker clock (not UTC) · ${m15.candles.at(-1).time}`, 'good');
      setStatus('apiStatus', `Fetched ${h1.candles.length} H1 and ${m15.candles.length} M15 candles. Historical only. ${[...h1.validation.warnings, ...m15.validation.warnings].join(' ')}`, 'warn');
    } catch (e) {
      setStatus('apiStatus', `${e.message} You can still import broker-exported CSV files below.`, 'bad');
    } finally { button.disabled = false; button.textContent = 'Fetch H1 + M15 historical candles'; }
  });
  $('h1file').addEventListener('change', () => readFile('h1file', 'h1', 'h1status', 'H1'));
  $('m15file').addEventListener('change', () => readFile('m15file', 'm15', 'm15status', 'M15'));
  function fmt(n) { return Number.isFinite(n) ? n.toFixed(2) : '—'; }
  function analyze() {
    if (!state.h1 || !state.m15) return setStatus('dataStatus', 'Load both H1 and M15 CSV files first.', 'bad');
    const result = XAUUSD.Orchestrator.scan(state.h1, state.m15, { atrMultiplier: 1.5, rewardRisk: 2, maxRiskPercent: 0.5 });
    if (result.stage === 'DATA_REJECTED') return setStatus('dataStatus', result.reasons.join(' '), 'bad');
    $('signal').textContent = result.decision;
    $('signal').className = `signal ${result.decision.toLowerCase()}`;
    $('trend').textContent = result.market.trend;
    $('rsi').textContent = fmt(result.signal.rsi14);
    $('atr').textContent = fmt(result.signal.atr14);
    $('entry').textContent = fmt(result.signal.close);
    $('sl').textContent = fmt(result.risk.stopLoss);
    $('tp').textContent = fmt(result.risk.takeProfit);
    $('distance').textContent = fmt(result.risk.stopDistance);
    $('candleTime').textContent = result.signal.candleTime;
    $('reason').textContent = result.reasons.join(' ');
    const warnings = result.data.warnings.join(' ');
    const reviewer = result.review.verdict;
    setStatus('dataStatus', `${reviewer} · H1 ${result.completedH1Count} completed / ${state.h1.candles.length} loaded · M15 ${result.completedM15Count} completed / ${state.m15.candles.length} loaded · Signal bar: ${result.signal.candleTime}. The final CSV row is excluded unless a later candle confirms its close; this is historical data, not a live quote.${warnings ? ` Warning: ${warnings}` : ''}`, reviewer === 'PASS' ? 'good' : 'warn');
    $('review').textContent = `${reviewer}${result.review.issues.length ? `: ${result.review.issues.join(' ')}` : ': no critical consistency issue detected.'}`;
    $('agents').textContent = result.agents.join(' → ');
    $('stopdist').value = Number.isFinite(result.risk.stopDistance) ? result.risk.stopDistance.toFixed(2) : '';
  }
  $('analyze').addEventListener('click', analyze);

  $('runBacktest').addEventListener('click', () => {
    if (!state.h1 || !state.m15) return setStatus('backtestStatus', 'Load both H1 and M15 historical datasets first.', 'bad');
    const button = $('runBacktest'); button.disabled = true; button.textContent = 'Running…';
    try {
      const result = XAUUSD.Backtester.run({
        h1: state.h1, m15: state.m15,
        settings: { atrMultiplier: 1.5, rewardRisk: 2, maxHoldingBars: Number($('btHold').value), spreadCostPrice: Number($('btSpreadCost').value), commissionCostPrice: Number($('btCommissionCost').value), slippageCostPrice: Number($('btSlippageCost').value) }
      });
      if (!result.valid) { state.lastBacktest = null; $('exportAudit').disabled = true; $('backtestResults').textContent = 'Backtest rejected: ' + result.errors.join(' '); return setStatus('backtestStatus', 'Backtest could not run.', 'bad'); }
      state.lastBacktest = result; $('exportAudit').disabled = false;
      const s = result.summary;
      const pf = s.profitFactor === Infinity ? '∞ (no losing trades)' : Number.isFinite(s.profitFactor) ? s.profitFactor.toFixed(2) : '—';
      $('backtestResults').textContent = [
        `M15 timestamp-grid coverage: ${result.dataCoverage.observedCandles}/${result.dataCoverage.gridSlots} slots (${Number.isFinite(result.dataCoverage.timestampGridCoveragePercent) ? result.dataCoverage.timestampGridCoveragePercent.toFixed(1) + '%' : '—'}) · Gaps: ${result.dataCoverage.gapCount} · Missing grid slots: ${result.dataCoverage.missingIntervalSlots} · Largest gap: ${result.dataCoverage.maxGapMinutes} min`,
        `Coverage caveat: ${result.dataCoverage.interpretation}`,
        ...result.trades.map(t => `TRADE ${t.side}: ${t.barsHeld} observed bars · elapsed exposure ${t.elapsedExposureLowerBoundMinutes}–${t.elapsedExposureUpperBoundMinutes} min · exit timing ${t.exitTimingPrecision}`),
        `Closed trades: ${s.closedTrades} · Signals: ${result.signals} · Skipped after M15 gaps: ${result.skippedGapEntries} · Unresolved at data end: ${result.unresolvedSignals}`,
        ...(result.unresolvedTrades || []).map(t => `UNRESOLVED ${t.side}: entry ${t.entryTime} @ ${t.entryPrice} · last observed ${t.lastObservedTime} close ${t.lastObservedClose} · ${t.barsHeld} observed bars · elapsed exposure ${t.elapsedExposureLowerBoundMinutes}–${t.elapsedExposureUpperBoundMinutes} min (not a closed trade)`),
        `Wins: ${s.wins} · Losses: ${s.losses} · Breakeven: ${s.breakeven} · Win rate: ${Number.isFinite(s.winRatePercent) ? s.winRatePercent.toFixed(1) + '%' : '—'}`,
        `Net result: ${s.netR.toFixed(2)}R · Expectancy: ${Number.isFinite(s.expectancyR) ? s.expectancyR.toFixed(3) + 'R/trade' : '—'} · Profit factor: ${pf}`,
        `Maximum drawdown: ${s.maxDrawdownR.toFixed(2)}R · Gross profit: ${s.grossProfitR.toFixed(2)}R · Gross loss: ${s.grossLossR.toFixed(2)}R`,
        `Method: ${result.method}. No live or broker-verified performance is implied.`
      ].join('\n');
      $('backtestResults').style.whiteSpace = 'pre-line';
      setStatus('backtestStatus', `Backtest complete on ${state.h1.candles.length} H1 and ${state.m15.candles.length} M15 candles. Total estimated costs: ${result.parameters.totalRoundTripCostPrice} XAU price units round-trip. Review assumptions below.`, 'warn');
    } catch (e) { state.lastBacktest = null; $('exportAudit').disabled = true; setStatus('backtestStatus', `Backtest failed safely: ${e.message}`, 'bad'); }
    finally { button.disabled = false; button.textContent = 'Run historical backtest'; }
  });

  $('exportAudit').addEventListener('click', () => {
    if (!state.lastBacktest || !state.h1 || !state.m15) return setStatus('backtestStatus', 'Run a valid backtest before exporting its audit ledger.', 'bad');
    try {
      const csv = XAUUSD.AuditLedger.createCSV({ result: state.lastBacktest, h1: state.h1, m15: state.m15 });
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url; link.download = 'XAUUSD_trade_audit_v0.4.2.csv';
      document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
      setStatus('backtestStatus', `Exported ${state.lastBacktest.trades.length} closed trade record(s). CSV is an analysis ledger, not a broker execution statement.`, 'good');
    } catch (e) { setStatus('backtestStatus', `Audit export failed safely: ${e.message}`, 'bad'); }
  });

  $('runOOS').addEventListener('click', () => {
    if (!state.h1 || !state.m15) return setStatus('oosStatus', 'Load both H1 and M15 historical datasets first.', 'bad');
    const button = $('runOOS'); button.disabled = true; button.textContent = 'Running holdout…';
    try {
      const holdout = XAUUSD.Backtester.runOutOfSample({
        h1: state.h1, m15: state.m15, trainFraction: 0.7,
        settings: { atrMultiplier: 1.5, rewardRisk: 2, maxHoldingBars: Number($('btHold').value), spreadCostPrice: Number($('btSpreadCost').value), commissionCostPrice: Number($('btCommissionCost').value), slippageCostPrice: Number($('btSlippageCost').value) }
      });
      if (!holdout.valid) { $('oosResults').textContent = 'Holdout rejected: ' + holdout.errors.join(' '); return setStatus('oosStatus', 'Holdout test could not run.', 'bad'); }
      const s = holdout.result.summary;
      $('oosResults').textContent = [
        `Split: ${Math.round(holdout.trainFraction * 100)}% warm-up/training · ${Math.round((1-holdout.trainFraction) * 100)}% test`,
        `Test window: ${holdout.testStartTime} → ${holdout.testEndTime} · Test M15 bars: ${holdout.testBars}`,
        `Test-window timestamp-grid coverage: ${holdout.testCoverage.observedCandles}/${holdout.testCoverage.gridSlots} slots (${Number.isFinite(holdout.testCoverage.timestampGridCoveragePercent) ? holdout.testCoverage.timestampGridCoveragePercent.toFixed(1) + '%' : '—'}) · Gaps: ${holdout.testCoverage.gapCount} · Missing grid slots: ${holdout.testCoverage.missingIntervalSlots} · Largest gap: ${holdout.testCoverage.maxGapMinutes} min`,
        `Coverage caveat: ${holdout.testCoverage.interpretation}`,
        ...holdout.result.trades.map(t => `TRADE ${t.side}: ${t.barsHeld} observed bars · elapsed exposure ${t.elapsedExposureLowerBoundMinutes}–${t.elapsedExposureUpperBoundMinutes} min · exit timing ${t.exitTimingPrecision}`),
        `Boundary policy: unresolved positions at the final test candle are excluded from closed-trade metrics; no post-test candles are used.`,
        `Closed trades: ${s.closedTrades} · Signals: ${holdout.result.signals} · Skipped after M15 gaps: ${holdout.result.skippedGapEntries} · Unresolved: ${holdout.result.unresolvedSignals}`,
        ...(holdout.result.unresolvedTrades || []).map(t => `UNRESOLVED ${t.side}: entry ${t.entryTime} @ ${t.entryPrice} · last observed ${t.lastObservedTime} close ${t.lastObservedClose} · ${t.barsHeld} observed bars · elapsed exposure ${t.elapsedExposureLowerBoundMinutes}–${t.elapsedExposureUpperBoundMinutes} min (not a closed trade)`),
        `Net: ${s.netR.toFixed(2)}R · Expectancy: ${Number.isFinite(s.expectancyR) ? s.expectancyR.toFixed(3) + 'R/trade' : '—'} · Win rate: ${Number.isFinite(s.winRatePercent) ? s.winRatePercent.toFixed(1) + '%' : '—'}`,
        `Profit factor: ${s.profitFactor === Infinity ? '∞ (no losses)' : Number.isFinite(s.profitFactor) ? s.profitFactor.toFixed(2) : '—'} · Max drawdown: ${s.maxDrawdownR.toFixed(2)}R`,
        `Warning: ${holdout.warning}`
      ].join('\n');
      $('oosResults').style.whiteSpace = 'pre-line';
      setStatus('oosStatus', 'Chronological holdout completed. Earlier candles were retained only for warm-up; signals were gated to the test period. This is not proof of an edge.', 'warn');
    } catch (e) { setStatus('oosStatus', `Holdout failed safely: ${e.message}`, 'bad'); }
    finally { button.disabled = false; button.textContent = 'Run 70/30 holdout test'; }
  });

  $('clear').addEventListener('click', () => {
    state.h1 = state.m15 = null; state.lastBacktest = null; $('exportAudit').disabled = true; $('h1file').value = $('m15file').value = '';
    setStatus('h1status', 'No H1 file loaded.'); setStatus('m15status', 'No M15 file loaded.');
    setStatus('dataStatus', 'Files cleared.'); $('signal').textContent = 'WAIT'; $('signal').className = 'signal wait';
    ['trend','rsi','atr','entry','sl','tp','distance','candleTime','review','agents','reason'].forEach(id => $(id).textContent = '—');
    $('backtestResults').textContent = 'No backtest run yet.'; $('oosResults').textContent = 'No holdout test run yet.'; setStatus('backtestStatus', 'Import or fetch validated H1 and M15 history first.'); setStatus('oosStatus', 'Load validated H1 and M15 history first.');
  });
  $('calc').addEventListener('click', () => {
    const result = XAUUSD.RiskAnalyst.calculatePositionSize({
      balance: Number($('balance').value), riskPercent: Number($('risk').value),
      stopDistance: Number($('stopdist').value), usdPerOneDollarMovePerLot: Number($('contract').value),
      minLot: Number($('minLot').value), lotStep: Number($('lotStep').value), maxLot: Number($('maxLot').value)
    });
    setStatus('lotresult', result.valid ? `Indicative size: ${result.lots} lots · Estimated risk: $${result.estimatedRisk.toFixed(2)} · Requested risk budget: $${result.riskCash.toFixed(2)}. Verify the broker's contract, tick value, lot step, fees and slippage.` : result.error, result.valid ? 'warn' : 'bad');
  });
})();
