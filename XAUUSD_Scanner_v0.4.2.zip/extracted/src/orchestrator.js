(function (root) {
  const M15_INTERVAL_MS = 15 * 60 * 1000;
  function latestCompletedCandleIndex(candles, intervalMs) {
    // Candle timestamps are opens. A candle is considered complete only when a later row
    // opens at or after its scheduled close. Never infer completion from the device clock:
    // MetaTrader timestamps may be broker-server wall-clock values.
    for (let i = candles.length - 2; i >= 0; i--) {
      if (candles[i + 1].timestamp >= candles[i].timestamp + intervalMs) return i;
    }
    return -1;
  }
  function scan(h1, m15, settings = {}) {
    const data = root.XAUUSD.DataIntegrity.validateDataset(h1, m15);
    if (!data.valid) return { decision: 'WAIT', stage: 'DATA_REJECTED', data, reasons: data.errors, agents: [] };
    const signalIndex = latestCompletedCandleIndex(m15.candles, M15_INTERVAL_MS);
    const completedM15 = signalIndex >= 0 ? m15.candles.slice(0, signalIndex + 1) : [];
    if (completedM15.length < 30) return { decision: 'WAIT', stage: 'DATA_REJECTED', data, reasons: [`Only ${completedM15.length} demonstrably completed M15 candles are available; at least 30 are required. The final CSV row cannot be confirmed complete without a later candle timestamp.`], agents: [] };
    // H1 bars must be complete by the close of the selected, confirmed M15 signal bar.
    const signalCandle = completedM15.at(-1);
    const signalCandleCloseTime = signalCandle.timestamp + M15_INTERVAL_MS;
    const completedH1 = h1.candles.filter(c => c.timestamp + 60 * 60 * 1000 <= signalCandleCloseTime);
    if (completedH1.length < 210) return { decision: 'WAIT', stage: 'DATA_REJECTED', data, reasons: [`Only ${completedH1.length} completed H1 candles are available at the selected M15 signal close; at least 210 are required.`], agents: [] };
    const market = root.XAUUSD.MarketAnalyst.analyzeH1(completedH1);
    const signal = root.XAUUSD.SignalAnalyst.analyzeM15(completedM15, market);
    const risk = root.XAUUSD.RiskAnalyst.assess(signal, settings);
    const review = root.XAUUSD.QualityReviewer.review(data, market, signal, risk);
    const decision = review.approved && risk.valid ? signal.candidate : 'WAIT';
    const reasons = decision === 'WAIT' ? (review.issues.length ? review.issues : signal.reasons) : signal.reasons;
    return { decision, stage: 'COMPLETE', data, market, completedH1Count: completedH1.length, completedM15Count: completedM15.length, signalCandleIndex: signalIndex, signalCandleCloseTime, signal, risk, review, reasons, agents: ['Data Integrity', 'Market Analyst', 'Signal Analyst', 'Risk Analyst', 'Quality Reviewer'], disclaimer: 'Historical CSV analysis only. No live market feed, no execution, and no evidence of a profitable edge.' };
  }
  root.XAUUSD = root.XAUUSD || {};
  root.XAUUSD.Orchestrator = { scan, latestCompletedCandleIndex };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.XAUUSD.Orchestrator;
})(globalThis);
