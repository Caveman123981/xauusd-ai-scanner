(function (root) {
  function review(dataset, market, signal, risk) {
    const issues = [];
    if (!dataset.valid) issues.push('Data validation failed.');
    if (!['BULLISH', 'BEARISH', 'NEUTRAL'].includes(market.trend)) issues.push('Market trend output is invalid.');
    if (!['BUY', 'SELL', 'WAIT'].includes(signal.candidate)) issues.push('Signal candidate is invalid.');
    if (signal.candidate === 'BUY' && market.trend !== 'BULLISH') issues.push('BUY conflicts with H1 market trend.');
    if (signal.candidate === 'SELL' && market.trend !== 'BEARISH') issues.push('SELL conflicts with H1 market trend.');
    if (signal.candidate !== 'WAIT' && !risk.valid) issues.push('Risk assessment failed.');
    if (signal.candidate === 'BUY' && risk.valid && !(risk.stopLoss < signal.close && risk.takeProfit > signal.close)) issues.push('BUY stop/target geometry is invalid.');
    if (signal.candidate === 'SELL' && risk.valid && !(risk.stopLoss > signal.close && risk.takeProfit < signal.close)) issues.push('SELL stop/target geometry is invalid.');
    if (signal.candidate !== 'WAIT' && (!Number.isFinite(signal.rsi14) || !Number.isFinite(signal.atr14))) issues.push('Signal indicator values are incomplete.');
    return { agent: 'Quality Reviewer', approved: issues.length === 0, issues, verdict: issues.length ? 'REJECT' : 'PASS' };
  }
  root.XAUUSD = root.XAUUSD || {};
  root.XAUUSD.QualityReviewer = { review };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.XAUUSD.QualityReviewer;
})(globalThis);
