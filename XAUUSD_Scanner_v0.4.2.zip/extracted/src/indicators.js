(function (root) {
  function ema(values, period) {
    const out = Array(values.length).fill(null);
    if (!Number.isInteger(period) || period < 1 || values.length < period) return out;
    const alpha = 2 / (period + 1);
    let current = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
    out[period - 1] = current;
    for (let i = period; i < values.length; i++) { current = values[i] * alpha + current * (1 - alpha); out[i] = current; }
    return out;
  }
  function rsi(values, period = 14) {
    const out = Array(values.length).fill(null);
    if (!Number.isInteger(period) || period < 1 || values.length <= period) return out;
    let gains = 0, losses = 0;
    for (let i = 1; i <= period; i++) { const d = values[i] - values[i - 1]; gains += Math.max(d, 0); losses += Math.max(-d, 0); }
    let avgGain = gains / period, avgLoss = losses / period;
    out[period] = avgLoss === 0 ? (avgGain === 0 ? 50 : 100) : 100 - 100 / (1 + avgGain / avgLoss);
    for (let i = period + 1; i < values.length; i++) {
      const d = values[i] - values[i - 1];
      avgGain = (avgGain * (period - 1) + Math.max(d, 0)) / period;
      avgLoss = (avgLoss * (period - 1) + Math.max(-d, 0)) / period;
      out[i] = avgLoss === 0 ? (avgGain === 0 ? 50 : 100) : 100 - 100 / (1 + avgGain / avgLoss);
    }
    return out;
  }
  function atr(candles, period = 14) {
    const out = Array(candles.length).fill(null);
    if (!Number.isInteger(period) || period < 1 || candles.length <= period) return out;
    const tr = candles.map((c, i) => i === 0 ? c.high - c.low : Math.max(c.high - c.low, Math.abs(c.high - candles[i - 1].close), Math.abs(c.low - candles[i - 1].close)));
    let current = tr.slice(1, period + 1).reduce((a, b) => a + b, 0) / period;
    out[period] = current;
    for (let i = period + 1; i < tr.length; i++) { current = (current * (period - 1) + tr[i]) / period; out[i] = current; }
    return out;
  }
  root.XAUUSD = root.XAUUSD || {};
  root.XAUUSD.Indicators = { ema, rsi, atr };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.XAUUSD.Indicators;
})(globalThis);
