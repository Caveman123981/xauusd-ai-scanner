(function (root) {
  function analyzeH1(candles) {
    const I = root.XAUUSD.Indicators;
    const closes = candles.map(c => c.close);
    const e20 = I.ema(closes, 20), e50 = I.ema(closes, 50), e200 = I.ema(closes, 200);
    const i = candles.length - 1;
    let trend = 'NEUTRAL';
    if (closes[i] > e50[i] && e20[i] > e50[i] && e50[i] > e200[i]) trend = 'BULLISH';
    else if (closes[i] < e50[i] && e20[i] < e50[i] && e50[i] < e200[i]) trend = 'BEARISH';
    return { agent: 'Market Analyst', timeframe: 'H1', trend, close: closes[i], ema20: e20[i], ema50: e50[i], ema200: e200[i], candleTime: candles[i].time };
  }
  root.XAUUSD = root.XAUUSD || {};
  root.XAUUSD.MarketAnalyst = { analyzeH1 };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.XAUUSD.MarketAnalyst;
})(globalThis);
